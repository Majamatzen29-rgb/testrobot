Config = {}

-- ============================================================
-- OWNER (server-side only – never sent to clients)
-- ============================================================
Config.OwnerLicense = "license:f9cb3badb8434d9d84217f8e11027096dc0819c3"
Config.OwnerName = "Captain Jack"

-- ============================================================
-- LIMITS & DEFAULTS
-- ============================================================
Config.MaxRobots = 100

Config.RobotHealth = 1000
Config.RobotMaxHealth = 1000
Config.RobotArmor = 100

Config.SpawnDistance = 3.0
Config.SpawnOffsetStep = 1.2

Config.DefaultWeapon = "WEAPON_PISTOL"
Config.DefaultAmmo = 100

Config.WeaponAccuracy = 60
Config.CombatAbility = 2
Config.DetectionDistance = 100.0

Config.VehicleModel = "blista"
Config.TestWallCoords = vector3(0.0, 0.0, 0.0) -- set a test wall location if desired
Config.TestWallHeading = 0.0

Config.DefaultRobotPersonality = "Professional"

Config.DecisionInterval = 1500 -- ms between lightweight AI decision ticks
Config.ConversationHistoryLimit = 20

Config.Debug = false

-- ============================================================
-- OPTIONAL EXTERNAL AI (server-side keys only)
-- ============================================================
Config.AI = {
    Enabled = false,
    Provider = "none", -- "none" | "openai" | "custom"
    Endpoint = "",
    ApiKey = "",
    Model = "",
    MaxTokens = 300
}

-- ============================================================
-- OPTIONAL VOICE
-- ============================================================
Config.Voice = {
    Enabled = false,
    Provider = "none",
    Endpoint = "",
    ApiKey = ""
}
Config.VoiceOutput = false

-- ============================================================
-- WEBHOOK (server-side only)
-- ============================================================
Config.Webhook = {
    Enabled = false,
    URL = "",
    Name = "Test Robot",
    Avatar = ""
}

-- ============================================================
-- NAMES
-- ============================================================
Config.MaleNames = {
    "Johnny", "Joe", "Jack", "James", "John", "Michael", "Daniel", "David",
    "Alex", "Thomas", "William", "Oliver", "Lucas", "Noah", "Ethan", "Liam",
    "Benjamin", "Henry", "Samuel", "Charlie", "Leo", "Oscar", "Max", "Victor", "Arthur"
}

Config.FemaleNames = {
    "Maya", "Emma", "Sofia", "Emily", "Olivia", "Ava", "Ella", "Amelia",
    "Isabella", "Mia", "Freja", "Clara", "Luna", "Nora", "Anna", "Sarah",
    "Laura", "Alice", "Grace", "Chloe", "Sophie", "Victoria"
}

Config.RobotNames = {
    "Robo", "Unit-01", "Unit-02", "RX-01", "RX-02", "Atlas", "Titan",
    "Nova", "Echo", "Bolt", "Vector", "Omega"
}

-- ============================================================
-- PERSONALITIES
-- ============================================================
Config.Personalities = {
    "Friendly", "Professional", "Military", "Civilian", "Aggressive",
    "Coward", "Guard", "Funny", "Developer", "Neutral"
}

-- ============================================================
-- DEFAULT RULES (per AI)
-- ============================================================
Config.DefaultRules = {
    do_not_attack_owner     = true,
    obey_owner              = true,
    randomly_attack_people  = false,
    randomly_steal_vehicles = false,
    randomly_attack_civilians = false,
    use_weapons_without_command = false,
    leave_assigned_area     = false,
    speak_when_spoken_to    = true,
    follow_direct_commands  = true
}

-- ============================================================
-- WEAPONS
-- ============================================================
Config.Weapons = {
    "WEAPON_PISTOL",
    "WEAPON_COMBATPISTOL",
    "WEAPON_HEAVYPISTOL",
    "WEAPON_APPISTOL",
    "WEAPON_MICROSMG",
    "WEAPON_SMG",
    "WEAPON_ASSAULTSMG",
    "WEAPON_ASSAULTRIFLE",
    "WEAPON_CARBINERIFLE",
    "WEAPON_SPECIALCARBINE",
    "WEAPON_BULLPUPRIFLE",
    "WEAPON_PUMPSHOTGUN",
    "WEAPON_COMBATSHOTGUN",
    "WEAPON_ASSAULTSHOTGUN",
    "WEAPON_HEAVYSHOTGUN",
    "WEAPON_SNIPERRIFLE",
    "WEAPON_HEAVYSNIPER",
    "WEAPON_MARKSMANRIFLE",
    "WEAPON_KNIFE"
}

Config.WeaponLabels = {
    WEAPON_PISTOL          = "Pistol",
    WEAPON_COMBATPISTOL    = "Combat Pistol",
    WEAPON_HEAVYPISTOL     = "Heavy Pistol",
    WEAPON_APPISTOL        = "AP Pistol",
    WEAPON_MICROSMG        = "Micro SMG",
    WEAPON_SMG             = "SMG",
    WEAPON_ASSAULTSMG      = "Assault SMG",
    WEAPON_ASSAULTRIFLE    = "Assault Rifle",
    WEAPON_CARBINERIFLE    = "Carbine Rifle",
    WEAPON_SPECIALCARBINE  = "Special Carbine",
    WEAPON_BULLPUPRIFLE    = "Bullpup Rifle",
    WEAPON_PUMPSHOTGUN     = "Pump Shotgun",
    WEAPON_COMBATSHOTGUN   = "Combat Shotgun",
    WEAPON_ASSAULTSHOTGUN  = "Assault Shotgun",
    WEAPON_HEAVYSHOTGUN    = "Heavy Shotgun",
    WEAPON_SNIPERRIFLE     = "Sniper Rifle",
    WEAPON_HEAVYSNIPER     = "Heavy Sniper",
    WEAPON_MARKSMANRIFLE   = "Marksman Rifle",
    WEAPON_KNIFE           = "Knife"
}

-- ============================================================
-- DEFAULT INVENTORY ITEMS (standalone fallback)
-- ============================================================
Config.DefaultInventory = {
    { name = "pistol",      label = "Pistol",       count = 1,  type = "weapon" },
    { name = "pistol_ammo", label = "Pistol Ammo",  count = 50, type = "ammo" },
    { name = "knife",       label = "Knife",        count = 1,  type = "weapon" },
    { name = "medkit",      label = "Medical Kit",  count = 1,  type = "item" }
}

-- ============================================================
-- PED MODELS
-- ============================================================
Config.PedModels = {
    male   = { "a_m_y_business_01", "a_m_y_hipster_01", "a_m_m_business_01", "s_m_y_cop_01", "a_m_y_stbla_02" },
    female = { "a_f_y_business_01", "a_f_y_hipster_01", "a_f_y_bevhills_01", "a_f_m_bevhills_01", "a_f_y_tourist_01" },
    robot  = { "s_m_m_ciasec_01", "s_m_y_swat_01", "u_m_y_rsranger_01", "s_m_m_armoured_01", "s_m_y_blackops_01" }
}

-- ============================================================
-- ANIMATIONS
-- ============================================================
Config.Animations = {
    idle      = { dict = "amb@world_human_stand_impatient@male@idle_a", anim = "idle_a", flag = 1 },
    wave      = { dict = "friends@frj@ig_1", anim = "wave_a", flag = 49 },
    sit       = { dict = "anim@heists@fleeca_bank@ig_7_jetski_owner", anim = "owner_idle", flag = 1 },
    kneel     = { dict = "amb@medic@standing@kneel@base", anim = "base", flag = 1 },
    surrender = { dict = "random@arrests@busted", anim = "idle_a", flag = 1 },
    injured   = { dict = "move_injured_ground", anim = "sider_loop", flag = 1 }
}

-- ============================================================
-- MODES
-- ============================================================
Config.Modes = {
    "Passive", "Armed", "Hostile", "Invincible", "Frozen",
    "Mobile", "Melee", "Shooter", "Guard", "Flee", "Follow", "Wander"
}

-- ============================================================
-- SAFE NATURAL LANGUAGE → ACTION MAP
-- ============================================================
Config.NaturalCommands = {
    ["follow me"]           = "FOLLOW",
    ["come with me"]        = "FOLLOW",
    ["come here"]           = "FOLLOW",
    ["stay here"]           = "STOP",
    ["stop"]                = "STOP",
    ["stop following me"]   = "STOP",
    ["get in the car"]      = "ENTER_VEHICLE",
    ["get in"]              = "ENTER_VEHICLE",
    ["get out of the car"]  = "EXIT_VEHICLE",
    ["get out"]             = "EXIT_VEHICLE",
    ["drive forward"]       = "DRIVE",
    ["drive"]               = "DRIVE",
    ["stop the car"]        = "BRAKE",
    ["brake"]               = "BRAKE",
    ["run away"]            = "FLEE",
    ["flee"]                = "FLEE",
    ["guard this place"]    = "GUARD",
    ["guard"]               = "GUARD",
    ["use the shotgun"]     = "WEAPON_SHOTGUN",
    ["put your gun away"]   = "DISARM",
    ["sit down"]            = "ANIM_SIT",
    ["stand up"]            = "ANIM_STOP",
    ["wander"]              = "WANDER",
    ["attack"]              = "ATTACK",
    ["be passive"]          = "PASSIVE"
}

-- ============================================================
-- DISTURBANCE REACTIONS (by personality)
-- ============================================================
Config.DisturbanceReactions = {
    Friendly = {
        "Hey, careful there Captain Jack!",
        "What are you doing?",
        "Is everything alright?",
        "That tickles... please stop.",
        "I'm still friendly, but that was rough."
    },
    Professional = {
        "Captain Jack, what are you doing?",
        "Please clarify your intention.",
        "That was unnecessary.",
        "I will not escalate. Awaiting proper orders.",
        "This is not standard procedure."
    },
    Military = {
        "Sir, what is the objective?",
        "Standing by for clear orders.",
        "Confirm your intent, Captain.",
        "Holding discipline. Do not provoke further.",
        "Copy... still no hostile action authorized."
    },
    Civilian = {
        "Whoa, easy!",
        "What the hell is going on?",
        "Can you stop that?",
        "You're scaring me!",
        "Seriously, cut it out!"
    },
    Aggressive = {
        "What exactly are you trying to do?",
        "Seriously?",
        "Are you testing me again?",
        "Keep pushing and see what happens... within rules.",
        "I don't like games, Captain."
    },
    Coward = {
        "Uh... are you sure this is safe?",
        "Please don't do that...",
        "I'm getting nervous.",
        "Please stop, Captain Jack!",
        "I just want to stand here quietly..."
    },
    Guard = {
        "Stay alert.",
        "What is the status, Captain?",
        "Report.",
        "Position held. Disturbance noted.",
        "Do not interfere with the post."
    },
    Funny = {
        "Again? You really like testing me, Captain Jack.",
        "Okay... I don't know what you want me to do.",
        "Haha, very funny. Now what?",
        "Is this the part where I fall over on purpose?",
        "10/10 troll attempt. Still not attacking you."
    },
    Developer = {
        "Interesting test case.",
        "Logging that interaction.",
        "Are we debugging behaviour?",
        "Input: troll. Output: complaint. Loop continues.",
        "Personality module responding as designed."
    },
    Neutral = {
        "What do you want me to do?",
        "Can you make up your mind?",
        "Okay...",
        "That was unnecessary.",
        "I'm still here."
    }
}
