const app = document.getElementById('app');
const robotListEl = document.getElementById('robotList');
const activeCountEl = document.getElementById('activeCount');
const infoContent = document.getElementById('infoContent');
const modal = document.getElementById('modal');

let state = {
    robots: [],
    active: 0,
    max: 100,
    selected: null,
    robot: null,
    modes: [],
    weapons: [],
    weaponLabels: {},
    rules: null
};

function post(name, data) {
    fetch(`https://testrobot/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {})
    }).catch(() => {});
}

function closeUI() {
    app.classList.add('hidden');
    modal.classList.add('hidden');
    post('close');
}

document.getElementById('btnClose').addEventListener('click', closeUI);

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeUI();
});

// Tabs
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        tab.classList.add('active');
        const sec = document.getElementById('sec-' + tab.dataset.section);
        if (sec) sec.classList.add('active');
        if (tab.dataset.section === 'rules' && state.robot) {
            renderRules(state.robot.rules);
        }
        if (tab.dataset.section === 'inventory' && state.robot) {
            renderInventory(state.robot);
        }
        if (tab.dataset.section === 'stats' && state.robot) {
            renderStats(state.robot);
        }
        if (tab.dataset.section === 'talk' && state.robot) {
            renderTalk(state.robot.conversation || []);
        }
    });
});

function renderList() {
    activeCountEl.textContent = `Active AI: ${state.active} / ${state.max}`;
    robotListEl.innerHTML = '';
    if (!state.robots.length) {
        robotListEl.innerHTML = '<li class="muted" style="padding:12px">No AI spawned</li>';
        return;
    }
    state.robots.forEach(r => {
        const li = document.createElement('li');
        li.className = 'robot-item' + (r.id === state.selected ? ' selected' : '') + (r.dead ? ' dead' : '');
        li.innerHTML = `
            <span class="rid">AI ${r.id}</span>
            <span class="rname">${escapeHtml(r.name)}</span>
            <span class="rtype">${escapeHtml(r.type)}</span>
            <span class="rstate">${escapeHtml(r.state || '')}</span>
        `;
        li.addEventListener('click', () => {
            post('select', { id: r.id });
            state.selected = r.id;
            renderList();
        });
        li.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            post('action', { action: 'delete', id: r.id });
        });
        robotListEl.appendChild(li);
    });
}

function renderInfo(r) {
    if (!r) {
        infoContent.innerHTML = '<p class="muted">No AI selected</p>';
        return;
    }
    const wLabel = (state.weaponLabels && state.weaponLabels[r.weapon]) || r.weapon || 'None';
    infoContent.innerHTML = `
        <div class="name">AI ${r.id} — ${escapeHtml(r.name)}</div>
        <div><span class="label">Type:</span> <span class="val">${escapeHtml(r.type)}</span></div>
        <div><span class="label">Personality:</span> <span class="val">${escapeHtml(r.personality || '')}</span></div>
        <div><span class="label">Health:</span> <span class="val">${r.health} / ${r.maxHealth}</span></div>
        <div><span class="label">Armor:</span> <span class="val">${r.armor}</span></div>
        <div><span class="label">Weapon:</span> <span class="val">${escapeHtml(wLabel)}</span></div>
        <div><span class="label">Ammo:</span> <span class="val">${r.ammo || 0}</span></div>
        <div><span class="label">Mode:</span> <span class="val">${escapeHtml(r.mode || '')}</span></div>
        <div><span class="label">State:</span> <span class="val">${escapeHtml(r.state || '')}</span></div>
        <div><span class="label">Vehicle:</span> <span class="val">${r.vehicle ? 'Yes' : 'None'}</span></div>
    `;
}

function renderModes() {
    const grid = document.getElementById('modeGrid');
    grid.innerHTML = '';
    (state.modes || []).forEach(m => {
        const b = document.createElement('button');
        b.className = 'btn';
        b.textContent = m;
        b.addEventListener('click', () => post('action', { action: 'setMode', mode: m }));
        grid.appendChild(b);
    });
}

function renderWeapons() {
    const grid = document.getElementById('weaponGrid');
    grid.innerHTML = '';
    (state.weapons || []).forEach(w => {
        const b = document.createElement('button');
        b.className = 'btn';
        b.textContent = (state.weaponLabels && state.weaponLabels[w]) || w;
        b.addEventListener('click', () => post('action', { action: 'setWeapon', weapon: w }));
        grid.appendChild(b);
    });
}

function renderRules(rules) {
    const el = document.getElementById('rulesList');
    if (!rules) {
        el.innerHTML = '<p class="muted">Select an AI first</p>';
        return;
    }
    el.innerHTML = '';
    Object.keys(rules).forEach(key => {
        const div = document.createElement('div');
        div.className = 'rule-item';
        const on = rules[key];
        div.innerHTML = `<span>${key.replace(/_/g, ' ')}</span>`;
        const btn = document.createElement('button');
        btn.className = 'toggle' + (on ? ' on' : '');
        btn.addEventListener('click', () => {
            post('action', { action: 'setRule', rule: key, value: !on });
            rules[key] = !on;
            btn.classList.toggle('on');
        });
        div.appendChild(btn);
        el.appendChild(div);
    });
}

function renderInventory(r) {
    const el = document.getElementById('invContent');
    if (!r || !r.inventory) {
        el.innerHTML = '<p class="muted">Select an AI</p>';
        return;
    }
    if (!r.inventory.length) {
        el.innerHTML = '<p class="muted">Inventory empty</p>';
        return;
    }
    el.innerHTML = '';
    const isDead = r.state === 'Dead';
    r.inventory.forEach((item, idx) => {
        const div = document.createElement('div');
        div.className = 'inv-item';
        div.innerHTML = `<span>${escapeHtml(item.label || item.name)} x${item.count}</span>`;
        if (isDead) {
            const btn = document.createElement('button');
            btn.textContent = 'Loot';
            btn.addEventListener('click', () => {
                post('lootItem', { robotId: r.id, index: idx + 1 });
            });
            div.appendChild(btn);
        }
        el.appendChild(div);
    });
}

function renderStats(r) {
    const el = document.getElementById('statsContent');
    if (!r || !r.stats) {
        el.innerHTML = '<p class="muted">Select an AI</p>';
        return;
    }
    const s = r.stats;
    el.innerHTML = `
        <div class="stat-row"><span>Hits</span><span>${s.hits || 0}</span></div>
        <div class="stat-row"><span>Total Damage</span><span>${s.totalDamage || 0}</span></div>
        <div class="stat-row"><span>Last Damage</span><span>${s.lastDamage || 0}</span></div>
        <div class="stat-row"><span>Death Count</span><span>${s.deathCount || 0}</span></div>
        <div class="stat-row"><span>Health</span><span>${r.health} / ${r.maxHealth}</span></div>
        <div class="stat-row"><span>Armor</span><span>${r.armor}</span></div>
        <div class="stat-row"><span>State</span><span>${escapeHtml(r.state || '')}</span></div>
    `;
}

function renderTalk(history) {
    const el = document.getElementById('talkHistory');
    el.innerHTML = '';
    (history || []).forEach(line => {
        const div = document.createElement('div');
        div.className = 'talk-line';
        const isAI = line.from !== 'Captain Jack';
        div.innerHTML = `<span class="who${isAI ? ' ai' : ''}">${escapeHtml(line.from)}:</span> ${escapeHtml(line.text)}`;
        el.appendChild(div);
    });
    el.scrollTop = el.scrollHeight;
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// Spawn buttons
document.querySelectorAll('[data-spawn]').forEach(btn => {
    btn.addEventListener('click', () => {
        post('spawn', {
            type: btn.dataset.spawn,
            amount: 1,
            armed: btn.dataset.armed === '1'
        });
    });
});

// Control buttons
document.querySelectorAll('[data-ctrl]').forEach(btn => {
    btn.addEventListener('click', () => {
        post('action', { action: 'control', control: btn.dataset.ctrl });
    });
});

// Weapon disarm
document.querySelectorAll('[data-ctrl-weapon]').forEach(btn => {
    btn.addEventListener('click', () => {
        post('action', { action: 'setWeapon', weapon: btn.dataset.ctrlWeapon });
    });
});

// Anims
document.querySelectorAll('[data-anim]').forEach(btn => {
    btn.addEventListener('click', () => {
        post('action', { action: 'anim', anim: btn.dataset.anim });
    });
});

// Vehicles
document.querySelectorAll('[data-veh]').forEach(btn => {
    btn.addEventListener('click', () => {
        post('vehicle', { vehicleAction: btn.dataset.veh });
    });
});

// Health
document.getElementById('btnSetHealth').addEventListener('click', () => {
    const v = parseInt(document.getElementById('inputHealth').value, 10);
    post('setHealth', { amount: v });
});

document.getElementById('btnSetArmor').addEventListener('click', () => {
    const v = parseInt(document.getElementById('inputArmor').value, 10);
    post('setArmor', { amount: v });
});

document.getElementById('btnHeal').addEventListener('click', () => {
    post('action', { action: 'heal' });
});

document.getElementById('btnReset').addEventListener('click', () => {
    post('action', { action: 'reset' });
});

// Talk
document.getElementById('btnTalkSend').addEventListener('click', sendTalk);
document.getElementById('talkInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendTalk();
});
function sendTalk() {
    const input = document.getElementById('talkInput');
    const msg = input.value.trim();
    if (!msg) return;
    post('talk', { message: msg });
    input.value = '';
}
document.getElementById('btnTalkClear').addEventListener('click', () => {
    post('clearTalk');
    renderTalk([]);
});

// Delete all
document.getElementById('btnDeleteAll').addEventListener('click', () => {
    modal.classList.remove('hidden');
});
document.getElementById('modalCancel').addEventListener('click', () => {
    modal.classList.add('hidden');
});
document.getElementById('modalConfirm').addEventListener('click', () => {
    modal.classList.add('hidden');
    post('deleteAll');
});

// NUI Messages
window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || !data.type) return;

    if (data.type === 'open') {
        app.classList.remove('hidden');
        state.robots = data.robots || [];
        state.active = data.active || 0;
        state.max = data.max || 100;
        state.selected = data.selected;
        state.robot = data.robot || null;
        state.modes = data.modes || [];
        state.weapons = data.weapons || [];
        state.weaponLabels = data.weaponLabels || {};
        renderList();
        renderInfo(state.robot);
        renderModes();
        renderWeapons();
        if (state.robot) {
            renderRules(state.robot.rules);
            renderInventory(state.robot);
            renderStats(state.robot);
            renderTalk(state.robot.conversation || []);
        }
    } else if (data.type === 'updateList') {
        state.robots = data.robots || [];
        state.active = data.active || 0;
        state.max = data.max || 100;
        state.selected = data.selected;
        renderList();
    } else if (data.type === 'updateRobot') {
        state.robot = data.robot;
        state.selected = data.robot ? data.robot.id : null;
        renderInfo(state.robot);
        renderList();
        if (state.robot) {
            renderRules(state.robot.rules);
            renderInventory(state.robot);
            renderStats(state.robot);
            renderTalk(state.robot.conversation || []);
        }
    } else if (data.type === 'confirmDeleteAll') {
        app.classList.remove('hidden');
        modal.classList.remove('hidden');
    } else if (data.type === 'openSection') {
        app.classList.remove('hidden');
        const sec = data.section;
        if (sec === 'modes') {
            state.modes = data.modes || state.modes;
            renderModes();
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.querySelector('[data-section="behavior"]').classList.add('active');
            document.getElementById('sec-behavior').classList.add('active');
        } else if (sec === 'weapons') {
            state.weapons = data.weapons || state.weapons;
            state.weaponLabels = data.labels || state.weaponLabels;
            renderWeapons();
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.querySelector('[data-section="weapons"]').classList.add('active');
            document.getElementById('sec-weapons').classList.add('active');
        }
    } else if (data.type === 'showRules') {
        app.classList.remove('hidden');
        renderRules(data.rules);
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelector('[data-section="rules"]').classList.add('active');
        document.getElementById('sec-rules').classList.add('active');
    } else if (data.type === 'showStats') {
        app.classList.remove('hidden');
        renderStats({
            stats: data.stats,
            health: data.health,
            maxHealth: data.maxHealth,
            armor: data.armor,
            state: data.state
        });
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelector('[data-section="stats"]').classList.add('active');
        document.getElementById('sec-stats').classList.add('active');
    } else if (data.type === 'showInventory') {
        app.classList.remove('hidden');
        renderInventory({
            id: data.id,
            name: data.name,
            inventory: data.inventory,
            state: data.isDead ? 'Dead' : 'Idle'
        });
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelector('[data-section="inventory"]').classList.add('active');
        document.getElementById('sec-inventory').classList.add('active');
    } else if (data.type === 'openTalk') {
        app.classList.remove('hidden');
        renderTalk(data.history || []);
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelector('[data-section="talk"]').classList.add('active');
        document.getElementById('sec-talk').classList.add('active');
    } else if (data.type === 'talkUpdate') {
        renderTalk(data.history || []);
    }
});
