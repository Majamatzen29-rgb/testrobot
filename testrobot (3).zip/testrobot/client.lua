--[[
    testrobot – client.lua
    Entity spawning, AI behaviour, NUI, target interactions.
    NEVER contains owner license.
]]

local RobotPeds = {}       -- [netId] = { ped = entity, id = serverId, type = ..., ... }
local RobotVehicles = {}   -- [netId] = vehicle entity
local SelectedId = nil
local RobotList = {}
local ActiveCount = 0
local MaxCount = 100
local CurrentRobot = nil   -- detailed selected robot data
local NuiOpen = false
local DecisionThread = false
local HasOxLib = GetResourceState("ox_lib") == "started"
local HasOxTarget = GetResourceState("ox_target") == "started"
local HasQbTarget = GetResourceState("qb-target") == "started"

-- ============================================================
-- NOTIFY
-- ============================================================
RegisterNetEvent("testrobot:notify", function(msg, typ)
    if HasOxLib then
        lib.notify({ title = "TestRobot", description = msg, type = typ or "info" })
    else
        BeginTextCommandThefeedDisplay("STRING")
        AddTextComponentSubstringPlayerName(msg)
        EndTextCommandThefeedDisplay(0, false)
        -- simple fallback
        print(("[testrobot] %s"):format(msg))
    end
end)

local function Notify(msg, typ)
    TriggerEvent("testrobot:notify", msg, typ)
end

-- ============================================================
-- PED MODEL LOADER
-- ============================================================
local function LoadModel(model)
    local hash = type(model) == "string" and GetHashKey(model) or model
    if not IsModelInCdimage(hash) then return false end
    RequestModel(hash)
    local t = 0
    while not HasModelLoaded(hash) and t < 100 do
        Wait(10)
        t = t + 1
    end
    return HasModelLoaded(hash)
end

local function GetPedModel(rtype)
    local list = Config.PedModels[rtype] or Config.PedModels.robot
    return list[math.random(#list)]
end

-- ============================================================
-- SPAWN
-- ============================================================
RegisterNetEvent("testrobot:doSpawn", function(rtype, amount, armed)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)
    local inVehicle = IsPedInAnyVehicle(playerPed, false)

    if inVehicle then
        local veh = GetVehiclePedIsIn(playerPed, false)
        local right = GetOffsetFromEntityInWorldCoords(veh, 3.0, 0.0, 0.0)
        coords = right
    end

    local netIds = {}
    amount = tonumber(amount) or 1
    if amount < 1 then amount = 1 end
    if amount > 20 then amount = 20 end

    for i = 1, amount do
        local offset = (i - 1) * Config.SpawnOffsetStep
        local angle = heading * math.pi / 180.0
        local sx = coords.x + math.cos(angle + math.pi / 2) * (Config.SpawnDistance + offset)
        local sy = coords.y + math.sin(angle + math.pi / 2) * (Config.SpawnDistance + offset)
        local sz = coords.z

        local model = GetPedModel(rtype)
        if not LoadModel(model) then
            Notify("Failed to load ped model.", "error")
            goto continue
        end

        local ped = CreatePed(4, GetHashKey(model), sx, sy, sz - 1.0, heading, true, true)
        if not DoesEntityExist(ped) then goto continue end

        -- Mission entity so TXAdmin / entity tools can see and manage them
        SetEntityAsMissionEntity(ped, true, true)
        SetEntityCanBeDamaged(ped, true)
        SetEntityProofs(ped, false, false, false, false, false, false, false, false)
        SetPedFleeAttributes(ped, 0, false)
        SetPedCombatAttributes(ped, 46, true)
        SetPedCombatAttributes(ped, 5, true)
        SetPedCombatAbility(ped, Config.CombatAbility)
        SetPedAccuracy(ped, Config.WeaponAccuracy)
        SetPedCanRagdoll(ped, true)
        SetPedCanBeTargetted(ped, true)
        SetPedCanBeTargettedByPlayer(ped, PlayerId(), true)
        SetBlockingOfNonTemporaryEvents(ped, false) -- allow natural reactions when trolled
        SetPedConfigFlag(ped, 208, true)
        SetPedConfigFlag(ped, 281, true)
        SetPedConfigFlag(ped, 128, true) -- can be agitated
        SetEntityMaxHealth(ped, Config.RobotMaxHealth)
        SetEntityHealth(ped, Config.RobotHealth)
        SetPedArmour(ped, Config.RobotArmor)
        SetPedDiesWhenInjured(ped, false)
        SetPedKeepTask(ped, true)
        SetPedRelationshipGroupHash(ped, GetHashKey("CIVMALE"))
        SetPedHearingRange(ped, 60.0)
        SetPedSeeingRange(ped, 80.0)
        SetPedAlertness(ped, 2)
        -- Visible identity for admin tools / debugging
        SetPedAsGroupMember(ped, 0)

        if armed then
            local wHash = GetHashKey(Config.DefaultWeapon)
            GiveWeaponToPed(ped, wHash, Config.DefaultAmmo, false, true)
            SetCurrentPedWeapon(ped, wHash, true)
        end

        -- Network – exists on all machines so TXAdmin / other clients see the entity
        local netId = NetworkGetNetworkIdFromEntity(ped)
        SetNetworkIdCanMigrate(netId, true)
        SetNetworkIdExistsOnAllMachines(netId, true)
        NetworkRegisterEntityAsNetworked(ped)

        -- Blip for owner
        local blip = AddBlipForEntity(ped)
        SetBlipSprite(blip, 1)
        SetBlipColour(blip, rtype == "female" and 8 or (rtype == "robot" and 3 or 4))
        SetBlipScale(blip, 0.7)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName("AI Test Dummy")
        EndTextCommandSetBlipName(blip)

        RobotPeds[netId] = {
            ped = ped,
            type = rtype,
            lastTask = "idle",
            mode = armed and "Armed" or "Passive",
            blip = blip,
            id = nil,
            name = nil,
            personality = nil,
            speech = nil,
            speechUntil = 0,
            disturbCount = 0,
            lastHealth = Config.RobotHealth
        }
        netIds[#netIds + 1] = netId

        AddTargetToPed(ped, netId)

        ::continue::
    end

    if #netIds > 0 then
        TriggerServerEvent("testrobot:registerSpawned", netIds, rtype, armed)
    end
end)

-- ============================================================
-- TARGET (ox_target / qb-target)
-- ============================================================
function AddTargetToPed(ped, netId)
    -- Normal interactable NPC so YOUR scripts/menus can target it
    SetPedCanBeTargetted(ped, true)
    SetPedCanBeTargettedByPlayer(ped, PlayerId(), true)
    SetEntityCanBeDamaged(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, false)

    if HasOxTarget then
        exports.ox_target:addLocalEntity(ped, {
            {
                name = "tr_inspect",
                icon = "fas fa-eye",
                label = "Inspect AI",
                distance = 2.5,
                onSelect = function()
                    TriggerServerEvent("testrobot:requestSync")
                    TriggerEvent("testrobot:openNUI")
                end
            },
            {
                name = "tr_talk",
                icon = "fas fa-comments",
                label = "Talk",
                distance = 2.5,
                onSelect = function()
                    ExecuteCommand("talk")
                end
            },
            {
                name = "tr_command",
                icon = "fas fa-terminal",
                label = "Open TestRobot Menu",
                distance = 2.5,
                onSelect = function()
                    ExecuteCommand("menu")
                end
            },
            {
                name = "tr_give",
                icon = "fas fa-hand-holding",
                label = "Give Item",
                distance = 2.5,
                onSelect = function()
                    Notify("Use your inventory/target on this dummy, or /menu → Inventory.", "info")
                end
            },
            {
                name = "tr_loot",
                icon = "fas fa-box-open",
                label = "Loot",
                distance = 2.5,
                canInteract = function()
                    return IsEntityDead(ped) or IsPedDeadOrDying(ped, true)
                end,
                onSelect = function()
                    TriggerServerEvent("testrobot:nuiAction", { action = "loot", netId = netId })
                    ExecuteCommand("menu")
                end
            }
        })
    elseif HasQbTarget then
        exports["qb-target"]:AddTargetEntity(ped, {
            options = {
                { type = "client", icon = "fas fa-eye", label = "Inspect AI", action = function() TriggerEvent("testrobot:openNUI") end },
                { type = "client", icon = "fas fa-comments", label = "Talk", action = function() ExecuteCommand("talk") end },
                { type = "client", icon = "fas fa-terminal", label = "Open TestRobot Menu", action = function() ExecuteCommand("menu") end },
                { type = "client", icon = "fas fa-box-open", label = "Loot", action = function() ExecuteCommand("menu") end }
            },
            distance = 2.5
        })
    end
end

-- ============================================================
-- EXPORTS – YOUR scripts can find these test dummies
-- ============================================================
exports("GetNearestRobot", function(maxDist)
    maxDist = maxDist or 5.0
    local pcoords = GetEntityCoords(PlayerPedId())
    local best, bestDist, bestNet = nil, maxDist, nil
    for netId, data in pairs(RobotPeds) do
        if DoesEntityExist(data.ped) then
            local d = #(pcoords - GetEntityCoords(data.ped))
            if d < bestDist then
                bestDist = d
                best = data.ped
                bestNet = netId
            end
        end
    end
    return best, bestNet, bestDist
end)

exports("GetRobotList", function()
    local list = {}
    for netId, data in pairs(RobotPeds) do
        if DoesEntityExist(data.ped) then
            list[#list + 1] = {
                ped = data.ped,
                netId = netId,
                id = data.id,
                name = data.name,
                personality = data.personality,
                type = data.type
            }
        end
    end
    return list
end)

exports("GetRobotPed", function(robotId)
    for netId, data in pairs(RobotPeds) do
        if data.id == robotId and DoesEntityExist(data.ped) then
            return data.ped, netId
        end
    end
    return nil, nil
end)

exports("IsTestRobot", function(entity)
    if not entity or not DoesEntityExist(entity) then return false end
    for netId, data in pairs(RobotPeds) do
        if data.ped == entity then return true, data.id, data.name end
    end
    local netId = NetworkGetNetworkIdFromEntity(entity)
    if RobotPeds[netId] then
        return true, RobotPeds[netId].id, RobotPeds[netId].name
    end
    return false
end)

-- ============================================================
-- IDENTITY FROM SERVER (name, personality, id)
-- ============================================================
RegisterNetEvent("testrobot:assignIdentity", function(netId, id, name, personality, rtype)
    if RobotPeds[netId] then
        RobotPeds[netId].id = id
        RobotPeds[netId].name = name
        RobotPeds[netId].personality = personality
        RobotPeds[netId].type = rtype or RobotPeds[netId].type
        if RobotPeds[netId].blip and DoesBlipExist(RobotPeds[netId].blip) then
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentSubstringPlayerName(("AI %d — %s"):format(id, name))
            EndTextCommandSetBlipName(RobotPeds[netId].blip)
        end
    end
end)

-- Floating speech bubble above AI
RegisterNetEvent("testrobot:aiSpeak", function(netId, text)
    if RobotPeds[netId] then
        RobotPeds[netId].speech = text
        RobotPeds[netId].speechUntil = GetGameTimer() + 5000
    end
    -- also notify owner in feed
    if text and text ~= "" then
        local name = (RobotPeds[netId] and RobotPeds[netId].name) or "AI"
        Notify(("[%s] %s"):format(name, text), "info")
    end
end)

-- ============================================================
-- DELETE ENTITY
-- ============================================================
RegisterNetEvent("testrobot:deleteEntity", function(netId, vehNetId)
    if netId and RobotPeds[netId] then
        local ped = RobotPeds[netId].ped
        if RobotPeds[netId].blip and DoesBlipExist(RobotPeds[netId].blip) then
            RemoveBlip(RobotPeds[netId].blip)
        end
        if DoesEntityExist(ped) then
            if HasOxTarget then pcall(function() exports.ox_target:removeLocalEntity(ped) end) end
            DeleteEntity(ped)
        end
        RobotPeds[netId] = nil
    end
    if netId then
        local ent = NetworkGetEntityFromNetworkId(netId)
        if DoesEntityExist(ent) then DeleteEntity(ent) end
    end
    if vehNetId then
        local veh = NetworkGetEntityFromNetworkId(vehNetId)
        if DoesEntityExist(veh) then DeleteEntity(veh) end
        RobotVehicles[vehNetId] = nil
    end
end)

-- ============================================================
-- APPLY ACTIONS
-- ============================================================
RegisterNetEvent("testrobot:applyAction", function(netId, action, robotId)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    local playerPed = PlayerPedId()
    local pcoords = GetEntityCoords(playerPed)

    ClearPedTasks(ped)
    SetBlockingOfNonTemporaryEvents(ped, true)

    if action == "FOLLOW" or action == "CHASE" then
        TaskFollowToOffsetOfEntity(ped, playerPed, 0.0, -1.5, 0.0, 5.0, -1, 1.0, true)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "follow" end
    elseif action == "STOP" or action == "STAND" or action == "PASSIVE" or action == "NOCOMBAT" then
        ClearPedTasks(ped)
        TaskStandStill(ped, -1)
        SetPedCombatAttributes(ped, 46, false)
        -- Keep interactable for external menus/scripts (ox_target, qb-target, etc.)
        SetBlockingOfNonTemporaryEvents(ped, false)
        SetPedCanBeTargetted(ped, true)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "idle" end
    elseif action == "ATTACK" or action == "COMBAT" then
        -- Attack nearest non-owner hostile if any; otherwise just combat ready
        SetPedCombatAttributes(ped, 46, true)
        SetPedCombatAttributes(ped, 5, true)
        TaskCombatHatedTargetsAroundPed(ped, Config.DetectionDistance, 0)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "combat" end
    elseif action == "GUARD" then
        local c = GetEntityCoords(ped)
        TaskGuardCurrentPosition(ped, 15.0, 15.0, true)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "guard" end
    elseif action == "FLEE" then
        TaskSmartFleePed(ped, playerPed, 100.0, -1, false, false)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "flee" end
    elseif action == "FREEZE" then
        FreezeEntityPosition(ped, true)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "frozen" end
    elseif action == "UNFREEZE" then
        FreezeEntityPosition(ped, false)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "idle" end
    elseif action == "WANDER" then
        TaskWanderStandard(ped, 10.0, 10)
        if RobotPeds[netId] then RobotPeds[netId].lastTask = "wander" end
    end
end)

RegisterNetEvent("testrobot:applyMode", function(netId, mode, invincible, frozen)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    SetEntityInvincible(ped, invincible and true or false)
    FreezeEntityPosition(ped, frozen and true or false)
    if mode == "Hostile" or mode == "Shooter" then
        SetPedCombatAttributes(ped, 46, true)
    elseif mode == "Passive" or mode == "Flee" then
        SetPedCombatAttributes(ped, 46, false)
    end
end)

RegisterNetEvent("testrobot:applyWeapon", function(netId, weapon, ammo)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    RemoveAllPedWeapons(ped, true)
    if weapon and weapon ~= "" then
        local hash = GetHashKey(weapon)
        GiveWeaponToPed(ped, hash, ammo or 0, false, true)
        SetCurrentPedWeapon(ped, hash, true)
    end
end)

RegisterNetEvent("testrobot:applyHealth", function(netId, health, armor, invincible)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    SetEntityMaxHealth(ped, Config.RobotMaxHealth)
    SetEntityHealth(ped, math.floor(health))
    SetPedArmour(ped, math.floor(armor or 0))
    SetEntityInvincible(ped, invincible and true or false)
end)

RegisterNetEvent("testrobot:revivePed", function(netId)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    local c = GetEntityCoords(ped)
    local h = GetEntityHeading(ped)
    NetworkResurrectLocalPlayer(c.x, c.y, c.z, h, true, false) -- not for ped
    -- Proper ped revive
    ResurrectPed(ped)
    ClearPedTasksImmediately(ped)
    SetEntityHealth(ped, Config.RobotMaxHealth)
    SetPedArmour(ped, Config.RobotArmor)
    SetEntityCoordsNoOffset(ped, c.x, c.y, c.z, false, false, false)
end)

RegisterNetEvent("testrobot:playAnim", function(netId, animName)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then return end
    ClearPedTasks(ped)
    if animName == "stop" then return end
    local a = Config.Animations[animName]
    if not a then return end
    RequestAnimDict(a.dict)
    local t = 0
    while not HasAnimDictLoaded(a.dict) and t < 50 do Wait(10); t = t + 1 end
    if HasAnimDictLoaded(a.dict) then
        TaskPlayAnim(ped, a.dict, a.anim, 8.0, -8.0, -1, a.flag or 1, 0, false, false, false)
    end
end)

-- ============================================================
-- RESPAWN
-- ============================================================
RegisterNetEvent("testrobot:respawnPed", function(id, rtype, oldNetId)
    local oldData = RobotPeds[oldNetId]
    local oldPed = NetworkGetEntityFromNetworkId(oldNetId)
    local coords = GetEntityCoords(PlayerPedId())
    local heading = GetEntityHeading(PlayerPedId())
    if DoesEntityExist(oldPed) then
        coords = GetEntityCoords(oldPed)
        heading = GetEntityHeading(oldPed)
        DeleteEntity(oldPed)
    end
    if oldData and oldData.blip and DoesBlipExist(oldData.blip) then
        RemoveBlip(oldData.blip)
    end
    RobotPeds[oldNetId] = nil

    local model = GetPedModel(rtype)
    if not LoadModel(model) then return end
    local ped = CreatePed(4, GetHashKey(model), coords.x, coords.y, coords.z - 1.0, heading, true, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetEntityCanBeDamaged(ped, true)
    SetPedCanBeTargetted(ped, true)
    SetEntityMaxHealth(ped, Config.RobotMaxHealth)
    SetEntityHealth(ped, Config.RobotHealth)
    SetPedArmour(ped, Config.RobotArmor)
    SetBlockingOfNonTemporaryEvents(ped, false)
    NetworkRegisterEntityAsNetworked(ped)
    local netId = NetworkGetNetworkIdFromEntity(ped)
    SetNetworkIdCanMigrate(netId, true)
    SetNetworkIdExistsOnAllMachines(netId, true)

    local blip = AddBlipForEntity(ped)
    SetBlipSprite(blip, 1)
    SetBlipColour(blip, 4)
    SetBlipScale(blip, 0.7)
    SetBlipAsShortRange(blip, true)

    RobotPeds[netId] = {
        ped = ped, type = rtype, lastTask = "idle", blip = blip,
        id = id, name = oldData and oldData.name or nil,
        personality = oldData and oldData.personality or nil,
        disturbCount = 0, lastHealth = Config.RobotHealth
    }
    if id and oldData and oldData.name then
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName(("AI %d — %s"):format(id, oldData.name))
        EndTextCommandSetBlipName(blip)
    end
    AddTargetToPed(ped, netId)
    TriggerServerEvent("testrobot:respawnDone", id, netId)
end)

-- ============================================================
-- VEHICLE COMMANDS
-- ============================================================
RegisterNetEvent("testrobot:vehicleCmd", function(netId, robotId, action, model, wallCoords, wallHeading)
    local ped = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(ped) then
        Notify("AI entity missing.", "error")
        return
    end

    action = tostring(action or ""):upper()

    if action == "SPAWN" then
        local c = GetEntityCoords(ped)
        local h = GetEntityHeading(ped)
        local m = model or Config.VehicleModel
        if not LoadModel(m) then Notify("Vehicle model failed.", "error"); return end
        local veh = CreateVehicle(GetHashKey(m), c.x + 3.0, c.y, c.z, h, true, true)
        SetEntityAsMissionEntity(veh, true, true)
        local vNet = NetworkGetNetworkIdFromEntity(veh)
        RobotVehicles[vNet] = veh
        TaskWarpPedIntoVehicle(ped, veh, -1)
        TriggerServerEvent("testrobot:vehicleRegistered", robotId, vNet)
        Notify("Vehicle spawned and AI entered.", "success")
    elseif action == "ENTER" then
        local veh = GetClosestVehicle(GetEntityCoords(ped), 10.0, 0, 70)
        if DoesEntityExist(veh) then
            TaskEnterVehicle(ped, veh, 5000, -1, 2.0, 1, 0)
        else
            Notify("No vehicle nearby.", "error")
        end
    elseif action == "EXIT" then
        if IsPedInAnyVehicle(ped, false) then
            TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 0)
            TriggerServerEvent("testrobot:vehicleCleared", robotId)
        else
            Notify("AI not in vehicle.", "error")
        end
    elseif action == "DRIVE" then
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local dest = GetOffsetFromEntityInWorldCoords(veh, 0.0, 50.0, 0.0)
            TaskVehicleDriveToCoord(ped, veh, dest.x, dest.y, dest.z, 20.0, 0, GetEntityModel(veh), 786603, 5.0, true)
        else
            Notify("AI not in vehicle.", "error")
        end
    elseif action == "REVERSE" then
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local dest = GetOffsetFromEntityInWorldCoords(veh, 0.0, -20.0, 0.0)
            TaskVehicleDriveToCoord(ped, veh, dest.x, dest.y, dest.z, 10.0, 0, GetEntityModel(veh), 786603, 5.0, true)
        end
    elseif action == "BRAKE" then
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            TaskVehicleTempAction(ped, veh, 1, 3000) -- brake
        end
    elseif action == "CRASH" or action == "DRIVE_WALL" then
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local target = wallCoords
            if not target or (target.x == 0 and target.y == 0 and target.z == 0) then
                target = GetOffsetFromEntityInWorldCoords(veh, 0.0, 40.0, 0.0)
            end
            TaskVehicleDriveToCoord(ped, veh, target.x, target.y, target.z, 40.0, 0, GetEntityModel(veh), 1074528293, 1.0, true)
            Notify("Driving toward test point / wall.", "info")
        else
            Notify("AI not in vehicle.", "error")
        end
    elseif action == "DELETE" then
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            TaskLeaveVehicle(ped, veh, 16)
            Wait(500)
            DeleteEntity(veh)
            TriggerServerEvent("testrobot:vehicleCleared", robotId)
            Notify("Vehicle deleted.", "success")
        else
            Notify("No vehicle.", "error")
        end
    end
end)

-- ============================================================
-- DAMAGE MONITORING (lightweight)
-- ============================================================
CreateThread(function()
    while true do
        Wait(1000)
        for netId, data in pairs(RobotPeds) do
            local ped = data.ped
            if DoesEntityExist(ped) then
                if IsEntityDead(ped) or IsPedDeadOrDying(ped, true) then
                    if data.lastTask ~= "dead" then
                        data.lastTask = "dead"
                        TriggerServerEvent("testrobot:reportDeath", netId)
                    end
                else
                    local health = GetEntityHealth(ped)
                    if data.lastHealth and health < data.lastHealth then
                        local dmg = data.lastHealth - health
                        TriggerServerEvent("testrobot:reportDamage", netId, dmg, nil, nil, nil)
                    end
                    data.lastHealth = health
                end
            end
        end
    end
end)

-- ============================================================
-- DISTURBANCE / TROLL DETECTION
-- Push, punch, shoot near, bump, vehicle hit → personality reaction
-- Never auto-attacks owner (rules enforced server-side)
-- ============================================================
local function ReactToTroll(netId, data, ped, reason)
    data.disturbCount = (data.disturbCount or 0) + 1
    data.lastTask = "annoyed"

    -- Face the owner
    local playerPed = PlayerPedId()
    TaskTurnPedToFaceEntity(ped, playerPed, 1500)

    -- Small physical reaction based on personality feel
    local personality = data.personality or "Neutral"
    if personality == "Coward" or personality == "Civilian" then
        -- step back
        local forward = GetEntityForwardVector(playerPed)
        local c = GetEntityCoords(ped)
        TaskGoStraightToCoord(ped, c.x - forward.x * 1.5, c.y - forward.y * 1.5, c.z, 1.0, 1500, 0.0, 0.1)
    elseif personality == "Aggressive" or personality == "Military" then
        -- stand firm and look
        TaskStandStill(ped, 2000)
    elseif personality == "Funny" then
        -- shrug / idle gesture
        RequestAnimDict("gestures@m@standing@casual")
        if HasAnimDictLoaded("gestures@m@standing@casual") then
            TaskPlayAnim(ped, "gestures@m@standing@casual", "gesture_shrug_hard", 4.0, -4.0, 1500, 48, 0, false, false, false)
        end
    else
        TaskLookAtEntity(ped, playerPed, 3000, 2048, 2)
    end

    TriggerServerEvent("testrobot:disturbance", netId, reason or "troll", data.disturbCount)
end

CreateThread(function()
    local lastDisturb = {}
    while true do
        Wait(250)
        local playerPed = PlayerPedId()
        local pcoords = GetEntityCoords(playerPed)
        local now = GetGameTimer()
        local shooting = IsPedShooting(playerPed)

        for netId, data in pairs(RobotPeds) do
            local ped = data.ped
            if DoesEntityExist(ped) and not IsEntityDead(ped) and not IsPedDeadOrDying(ped, true) then
                local coords = GetEntityCoords(ped)
                local dist = #(pcoords - coords)
                local cooldown = lastDisturb[netId] or 0
                local canReact = (now - cooldown) > 2500

                -- Damaged by owner (punch / shot / vehicle)
                if HasEntityBeenDamagedByEntity(ped, playerPed, true) and canReact then
                    lastDisturb[netId] = now
                    ClearEntityLastDamageEntity(ped)
                    ReactToTroll(netId, data, ped, "damage")
                -- Very close bump / push
                elseif dist < 1.2 and canReact then
                    local speed = GetEntitySpeed(playerPed)
                    if speed > 1.5 or IsPedRunning(playerPed) or IsPedSprinting(playerPed) then
                        lastDisturb[netId] = now
                        ReactToTroll(netId, data, ped, "bump")
                    end
                -- Owner shooting near the AI
                elseif shooting and dist < 12.0 and canReact then
                    lastDisturb[netId] = now
                    ReactToTroll(netId, data, ped, "gunfire")
                -- Owner aiming at AI
                elseif dist < 15.0 and IsPlayerFreeAiming(PlayerId()) and canReact then
                    local aiming, aimEnt = GetEntityPlayerIsFreeAimingAt(PlayerId())
                    if aiming and aimEnt == ped then
                        lastDisturb[netId] = now
                        ReactToTroll(netId, data, ped, "aim")
                    end
                end
            end
        end
    end
end)

-- ============================================================
-- NAME TAGS + SPEECH (3D text) – real character feel
-- ============================================================
local function DrawText3D(x, y, z, text, scale)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    SetTextScale(scale or 0.35, scale or 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 215)
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(_x, _y)
end

CreateThread(function()
    while true do
        local sleep = 500
        local playerPed = PlayerPedId()
        local pcoords = GetEntityCoords(playerPed)
        local now = GetGameTimer()

        for netId, data in pairs(RobotPeds) do
            local ped = data.ped
            if DoesEntityExist(ped) then
                local coords = GetEntityCoords(ped)
                local dist = #(pcoords - coords)
                if dist < 25.0 then
                    sleep = 0
                    local dead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true)
                    local id = data.id or "?"
                    local name = data.name or "AI"
                    local personality = data.personality or ""
                    local label
                    if dead then
                        label = ("~r~AI %s — %s [DEAD]"):format(id, name)
                    else
                        label = ("~b~AI %s~w~ — ~y~%s~w~\n~c~%s"):format(id, name, personality)
                    end
                    DrawText3D(coords.x, coords.y, coords.z + 1.05, label, 0.32)

                    -- Speech bubble
                    if data.speech and data.speechUntil and now < data.speechUntil then
                        DrawText3D(coords.x, coords.y, coords.z + 1.25, ("~o~\"%s\""):format(data.speech), 0.30)
                    elseif data.speechUntil and now >= data.speechUntil then
                        data.speech = nil
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

-- ============================================================
-- SYNC FROM SERVER
-- ============================================================
RegisterNetEvent("testrobot:syncList", function(list, count, max, selected)
    RobotList = list or {}
    ActiveCount = count or 0
    MaxCount = max or 100
    SelectedId = selected
    if NuiOpen then
        SendNUIMessage({
            type = "updateList",
            robots = RobotList,
            active = ActiveCount,
            max = MaxCount,
            selected = SelectedId
        })
    end
end)

RegisterNetEvent("testrobot:syncRobot", function(data)
    CurrentRobot = data
    SelectedId = data and data.id or nil
    if NuiOpen then
        SendNUIMessage({ type = "updateRobot", robot = data })
    end
end)

-- ============================================================
-- NUI
-- ============================================================
RegisterNetEvent("testrobot:openNUI", function()
    NuiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "open",
        robots = RobotList,
        active = ActiveCount,
        max = MaxCount,
        selected = SelectedId,
        robot = CurrentRobot,
        modes = Config.Modes,
        weapons = Config.Weapons,
        weaponLabels = Config.WeaponLabels,
        personalities = Config.Personalities
    })
end)

RegisterNetEvent("testrobot:confirmDeleteAll", function()
    SendNUIMessage({ type = "confirmDeleteAll" })
    if not NuiOpen then
        NuiOpen = true
        SetNuiFocus(true, true)
        SendNUIMessage({ type = "open", robots = RobotList, active = ActiveCount, max = MaxCount })
        Wait(100)
        SendNUIMessage({ type = "confirmDeleteAll" })
    end
end)

RegisterNetEvent("testrobot:openModeMenu", function(modes)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({ type = "openSection", section = "modes", modes = modes or Config.Modes })
end)

RegisterNetEvent("testrobot:openWeaponMenu", function(weapons, labels)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({ type = "openSection", section = "weapons", weapons = weapons, labels = labels })
end)

RegisterNetEvent("testrobot:showRules", function(id, name, rules)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({ type = "showRules", id = id, name = name, rules = rules })
end)

RegisterNetEvent("testrobot:showStats", function(id, name, stats, health, maxHealth, armor, state)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({
        type = "showStats",
        id = id, name = name, stats = stats,
        health = health, maxHealth = maxHealth, armor = armor, state = state
    })
end)

RegisterNetEvent("testrobot:showInventory", function(id, name, inventory, isDead)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({
        type = "showInventory",
        id = id, name = name, inventory = inventory, isDead = isDead
    })
end)

RegisterNetEvent("testrobot:openTalk", function(id, name, history)
    if not NuiOpen then
        TriggerEvent("testrobot:openNUI")
        Wait(200)
    end
    SendNUIMessage({ type = "openTalk", id = id, name = name, history = history or {} })
end)

RegisterNetEvent("testrobot:talkReply", function(id, name, history, reply)
    SendNUIMessage({ type = "talkUpdate", id = id, name = name, history = history, reply = reply })
end)

-- NUI Callbacks
RegisterNUICallback("close", function(_, cb)
    NuiOpen = false
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterNUICallback("action", function(data, cb)
    TriggerServerEvent("testrobot:nuiAction", data)
    cb("ok")
end)

RegisterNUICallback("talk", function(data, cb)
    if data and data.message then
        TriggerServerEvent("testrobot:talk", data.message)
    end
    cb("ok")
end)

RegisterNUICallback("clearTalk", function(_, cb)
    TriggerServerEvent("testrobot:clearConversation")
    cb("ok")
end)

RegisterNUICallback("lootItem", function(data, cb)
    if data and data.robotId and data.index then
        TriggerServerEvent("testrobot:lootItem", data.robotId, data.index)
    end
    cb("ok")
end)

RegisterNUICallback("select", function(data, cb)
    if data and data.id then
        TriggerServerEvent("testrobot:select", data.id)
    end
    cb("ok")
end)

RegisterNUICallback("deleteAll", function(data, cb)
    TriggerServerEvent("testrobot:deleteAll", true)
    cb("ok")
end)

RegisterNUICallback("spawn", function(data, cb)
    if data and data.type then
        local amount = tonumber(data.amount) or 1
        local rtype = data.type
        local armed = data.armed and true or false
        TriggerServerEvent("testrobot:requestSpawn", rtype, amount, armed)
    end
    cb("ok")
end)

RegisterNUICallback("setHealth", function(data, cb)
    if data and data.amount then
        TriggerServerEvent("testrobot:setHealth", tonumber(data.amount))
    end
    cb("ok")
end)

RegisterNUICallback("setArmor", function(data, cb)
    if data and data.amount then
        TriggerServerEvent("testrobot:setArmor", tonumber(data.amount))
    end
    cb("ok")
end)

RegisterNUICallback("vehicle", function(data, cb)
    if data and data.vehicleAction and SelectedId then
        TriggerServerEvent("testrobot:vehicleAction", data.vehicleAction)
    end
    cb("ok")
end)

-- ============================================================
-- CLEANUP
-- ============================================================
AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    for netId, data in pairs(RobotPeds) do
        if DoesEntityExist(data.ped) then DeleteEntity(data.ped) end
    end
    for _, veh in pairs(RobotVehicles) do
        if DoesEntityExist(veh) then DeleteEntity(veh) end
    end
    RobotPeds = {}
    RobotVehicles = {}
end)

print("^2[testrobot]^7 Client started.")
