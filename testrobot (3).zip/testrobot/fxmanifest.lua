fx_version 'cerulean'
game 'gta5'

name 'testrobot'
author 'Captain Jack'
description 'Advanced AI Test Dummy / Robot Testing Environment for FiveM'
version '1.0.0'

lua54 'yes'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

exports {
    'GetNearestRobot',
    'GetRobotList',
    'GetRobotPed',
    'IsTestRobot'
}
