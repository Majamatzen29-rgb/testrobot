--[[
    testrobot – server.lua
    All ownership checks, AI state, inventory, loot, webhooks live here.
    Owner license is NEVER sent to clients.
]]

local Framework = "standalone"
local QBCore, ESX, QBX = nil, nil, nil

-- ============================================================
-- FRAMEWORK DETECTION
-- ============================================================
CreateThread(function()
    if GetResourceState("qbx_core") == "started" then
        Framework = "qbox"
        QBX = exports.qbx_core
        print("^2[testrobot]^7 Framework detected: Qbox")
    elseif GetResourceState("qb-core") == "started" then
        Framework = "qbcore"
        QBCore = exports["qb-core"]:GetCoreObject()
        print("^2[testrobot]^7 Framework detected: QBCore")
    elseif GetResourceState("es_extended") == "started" then
        Framework = "esx"
        ESX = exports["es_extended"]:getSharedObject()
        print("^2[testrobot]^7 Framework detected: ESX")
    else
        Framework = "standalone"
        print("^3[testrobot]^7 Framework: Standalone")
    end
end)

-- ============================================================
-- AI STORAGE
-- ============================================================
local Robots = {}          -- [id] = robot data table
local NextId = 1
local FreeIds = {}         -- reusable IDs
local Selected = {}        -- [source] = selected robot id
local ResourceActive = true

local function GetFreeId()
    if #FreeIds > 0 then
        return table.remove(FreeIds, 1)
    end
    local id = NextId
    NextId = NextId + 1
    return id
end

local function CountRobots()
    local c = 0
    for _ in pairs(Robots) do c = c + 1 end
    return c
end

-- ============================================================
-- OWNER CHECK (server-side only)
-- ============================================================
local function IsOwner(src)
    if not src or src <= 0 then return false end
    local ids = GetPlayerIdentifiers(src)
    if not ids then return false end
    for _, id in ipairs(ids) do
        if id == Config.OwnerLicense then
            return true
        end
    end
    return false
end

local function Deny(src)
    TriggerClientEvent("testrobot:notify", src, "You don't have permission to use this. Owner: Captain Jack.", "error")
end

local function Notify(src, msg, typ)
    TriggerClientEvent("testrobot:notify", src, msg, typ or "info")
end

-- ============================================================
-- WEBHOOK
-- ============================================================
local function SendWebhook(title, description, color)
    if not Config.Webhook.Enabled or Config.Webhook.URL == "" then return end
    local embed = {
        {
            title = title,
            description = description,
            color = color or 3447003,
            footer = { text = "Test Robot • " .. os.date("%Y-%m-%d %H:%M:%S") }
        }
    }
    PerformHttpRequest(Config.Webhook.URL, function() end, "POST", json.encode({
        username = Config.Webhook.Name or "Test Robot",
        avatar_url = Config.Webhook.Avatar or "",
        embeds = embed
    }), { ["Content-Type"] = "application/json" })
end

-- ============================================================
-- NAME / PERSONALITY HELPERS
-- ============================================================
local function PickName(rtype)
    local list
    if rtype == "female" then
        list = Config.FemaleNames
    elseif rtype == "robot" then
        list = Config.RobotNames
    else
        list = Config.MaleNames
    end
    return list[math.random(#list)]
end

local function PickPersonality()
    return Config.Personalities[math.random(#Config.Personalities)]
end

local function CopyRules()
    local r = {}
    for k, v in pairs(Config.DefaultRules) do r[k] = v end
    return r
end

local function CopyInventory()
    local inv = {}
    for _, item in ipairs(Config.DefaultInventory) do
        inv[#inv + 1] = {
            name  = item.name,
            label = item.label,
            count = item.count,
            type  = item.type
        }
    end
    return inv
end

-- ============================================================
-- CREATE ROBOT DATA
-- ============================================================
local function CreateRobotData(rtype, netId, coords, armed)
    local id = GetFreeId()
    local name = PickName(rtype)
    local personality = PickPersonality()
    local weapon = armed and Config.DefaultWeapon or nil
    local ammo = armed and Config.DefaultAmmo or 0

    local data = {
        id           = id,
        name         = name,
        type         = rtype,          -- male / female / robot
        netId        = netId,
        personality  = personality,
        health       = Config.RobotHealth,
        maxHealth    = Config.RobotMaxHealth,
        armor        = Config.RobotArmor,
        weapon       = weapon,
        ammo         = ammo,
        mode         = armed and "Armed" or "Passive",
        state        = "Idle",
        vehicleNetId = nil,
        rules        = CopyRules(),
        inventory    = CopyInventory(),
        conversation = {},
        stats = {
            hits          = 0,
            totalDamage   = 0,
            lastDamage    = 0,
            lastWeapon    = nil,
            lastBone      = nil,
            lastAttacker  = nil,
            deathCount    = 0
        },
        frozen       = false,
        invincible   = false,
        createdAt    = os.time()
    }

    -- If default inventory already has a pistol and we are armed, sync ammo
    if armed then
        local found = false
        for _, it in ipairs(data.inventory) do
            if it.name == "pistol" then found = true; break end
        end
        if not found then
            data.inventory[#data.inventory + 1] = { name = "pistol", label = "Pistol", count = 1, type = "weapon" }
        end
    end

    Robots[id] = data
    return data
end

-- ============================================================
-- SYNC HELPERS
-- ============================================================
local function BuildPublicList()
    local list = {}
    for id, r in pairs(Robots) do
        list[#list + 1] = {
            id          = r.id,
            name        = r.name,
            type        = r.type,
            health      = r.health,
            maxHealth   = r.maxHealth,
            armor       = r.armor,
            weapon      = r.weapon,
            ammo        = r.ammo,
            mode        = r.mode,
            state       = r.state,
            personality = r.personality,
            vehicle     = r.vehicleNetId and true or false,
            dead        = r.state == "Dead"
        }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

local function SyncToOwner(src)
    if not IsOwner(src) then return end
    TriggerClientEvent("testrobot:syncList", src, BuildPublicList(), CountRobots(), Config.MaxRobots, Selected[src])
end

local function SyncRobot(src, id)
    local r = Robots[id]
    if not r then return end
    TriggerClientEvent("testrobot:syncRobot", src, {
        id          = r.id,
        name        = r.name,
        type        = r.type,
        health      = r.health,
        maxHealth   = r.maxHealth,
        armor       = r.armor,
        weapon      = r.weapon,
        ammo        = r.ammo,
        mode        = r.mode,
        state       = r.state,
        personality = r.personality,
        vehicle     = r.vehicleNetId,
        inventory   = r.inventory,
        rules       = r.rules,
        stats       = r.stats,
        conversation = r.conversation,
        frozen      = r.frozen,
        invincible  = r.invincible
    })
end

-- ============================================================
-- DELETE ROBOT
-- ============================================================
local function DeleteRobot(id)
    local r = Robots[id]
    if not r then return false end

    -- Tell all clients to clean entity
    TriggerClientEvent("testrobot:deleteEntity", -1, r.netId, r.vehicleNetId)

    FreeIds[#FreeIds + 1] = id
    table.sort(FreeIds)
    Robots[id] = nil

    -- Clear selections pointing to this id
    for src, sel in pairs(Selected) do
        if sel == id then Selected[src] = nil end
    end
    return true
end

local function DeleteAllRobots()
    for id in pairs(Robots) do
        DeleteRobot(id)
    end
    NextId = 1
    FreeIds = {}
    Selected = {}
end

-- ============================================================
-- SPAWN REQUEST
-- ============================================================
RegisterNetEvent("testrobot:requestSpawn", function(rtype, amount, armed)
    local src = source
    if not IsOwner(src) then Deny(src); return end

    amount = tonumber(amount) or 1
    if amount < 1 then amount = 1 end
    if amount > 20 then amount = 20 end -- safety per request

    local current = CountRobots()
    if current >= Config.MaxRobots then
        Notify(src, "You cannot spawn anymore. Delete a robot and spawn again, or try again next time.", "error")
        return
    end
    if current + amount > Config.MaxRobots then
        amount = Config.MaxRobots - current
        Notify(src, ("Limited to %d due to max capacity."):format(amount), "info")
    end

    rtype = rtype or "robot"
    if rtype ~= "male" and rtype ~= "female" and rtype ~= "robot" then
        rtype = "robot"
    end

    TriggerClientEvent("testrobot:doSpawn", src, rtype, amount, armed == true)
end)

RegisterNetEvent("testrobot:registerSpawned", function(netIds, rtype, armed)
    local src = source
    if not IsOwner(src) then return end

    local created = {}
    for _, netId in ipairs(netIds) do
        if CountRobots() >= Config.MaxRobots then break end
        local data = CreateRobotData(rtype, netId, nil, armed)
        created[#created + 1] = data.id
        -- Push identity to client so name tags / blips / TXAdmin label work
        TriggerClientEvent("testrobot:assignIdentity", -1, netId, data.id, data.name, data.personality, data.type)
        SendWebhook("AI Spawned", ("**%s** (%s) – ID %d – Personality: %s"):format(data.name, data.type, data.id, data.personality), 3066993)
    end

    if #created > 0 then
        Selected[src] = created[1]
        Notify(src, ("Spawned %d AI. Selected: AI %d"):format(#created, created[1]), "success")
        SyncToOwner(src)
    end
end)

-- ============================================================
-- SELECTION
-- ============================================================
RegisterNetEvent("testrobot:select", function(id)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    id = tonumber(id)
    if not id or not Robots[id] then
        Notify(src, "Invalid AI ID.", "error")
        return
    end
    Selected[src] = id
    SyncRobot(src, id)
    Notify(src, ("Selected AI %d — %s"):format(id, Robots[id].name), "success")
    SyncToOwner(src)
end)

local function GetSelected(src)
    local id = Selected[src]
    if not id or not Robots[id] then return nil end
    return Robots[id]
end

-- ============================================================
-- DELETE COMMANDS
-- ============================================================
RegisterNetEvent("testrobot:delete", function(id)
    local src = source
    if not IsOwner(src) then Deny(src); return end

    if id == nil or id == "" then
        local r = GetSelected(src)
        if not r then Notify(src, "No AI selected.", "error"); return end
        id = r.id
    else
        id = tonumber(id)
    end

    if not id or not Robots[id] then
        Notify(src, "AI missing or invalid ID.", "error")
        return
    end

    local name = Robots[id].name
    DeleteRobot(id)
    Notify(src, ("Deleted AI %d — %s"):format(id, name), "success")
    SendWebhook("AI Deleted", ("AI %d — %s deleted by owner."):format(id, name), 15158332)
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:deleteAll", function(confirm)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    if not confirm then
        TriggerClientEvent("testrobot:confirmDeleteAll", src)
        return
    end
    local count = CountRobots()
    DeleteAllRobots()
    Notify(src, ("Deleted all %d AI."):format(count), "success")
    SendWebhook("All AI Deleted", ("Owner deleted all %d AI."):format(count), 15158332)
    SyncToOwner(src)
end)

-- ============================================================
-- CONTROL ACTIONS
-- ============================================================
local ValidActions = {
    FOLLOW = true, STOP = true, ATTACK = true, PASSIVE = true,
    GUARD = true, FLEE = true, FREEZE = true, UNFREEZE = true,
    WANDER = true, STAND = true, CHASE = true, COMBAT = true,
    NOCOMBAT = true, ENTER_VEHICLE = true, EXIT_VEHICLE = true,
    DRIVE = true, BRAKE = true, REVERSE = true, CRASH = true,
    DRIVE_WALL = true, VEHICLE_OFF = true
}

RegisterNetEvent("testrobot:action", function(action, all)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    action = tostring(action or ""):upper()
    if not ValidActions[action] then
        Notify(src, "Invalid action.", "error")
        return
    end

    local targets = {}
    if all then
        for id, r in pairs(Robots) do
            if r.state ~= "Dead" then targets[#targets + 1] = r end
        end
    else
        local r = GetSelected(src)
        if not r then Notify(src, "No AI selected.", "error"); return end
        if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end
        targets[1] = r
    end

    for _, r in ipairs(targets) do
        if action == "FREEZE" then
            r.frozen = true
            r.state = "Frozen"
            r.mode = "Frozen"
        elseif action == "UNFREEZE" then
            r.frozen = false
            if r.state == "Frozen" then r.state = "Idle" end
            if r.mode == "Frozen" then r.mode = "Passive" end
        elseif action == "FOLLOW" then
            r.state = "Following"
            r.mode = "Follow"
        elseif action == "STOP" or action == "STAND" then
            r.state = "Idle"
            r.mode = "Passive"
        elseif action == "ATTACK" or action == "COMBAT" then
            if r.rules.do_not_attack_owner then
                -- still allow combat mode but client must respect owner
            end
            r.state = "Combat"
            r.mode = "Hostile"
        elseif action == "PASSIVE" or action == "NOCOMBAT" then
            r.state = "Passive"
            r.mode = "Passive"
        elseif action == "GUARD" then
            r.state = "Guarding"
            r.mode = "Guard"
        elseif action == "FLEE" then
            r.state = "Fleeing"
            r.mode = "Flee"
        elseif action == "WANDER" then
            r.state = "Wandering"
            r.mode = "Wander"
        elseif action == "CHASE" then
            r.state = "Following"
            r.mode = "Follow"
        end

        TriggerClientEvent("testrobot:applyAction", -1, r.netId, action, r.id)
        SendWebhook("Mode Changed", ("AI %d — %s → %s"):format(r.id, r.name, action), 15844367)
    end

    SyncToOwner(src)
    if not all then
        local r = GetSelected(src)
        if r then SyncRobot(src, r.id) end
    end
end)

-- ============================================================
-- MODE
-- ============================================================
RegisterNetEvent("testrobot:setMode", function(mode)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end

    local valid = false
    for _, m in ipairs(Config.Modes) do
        if m == mode then valid = true; break end
    end
    if not valid then Notify(src, "Invalid mode.", "error"); return end

    r.mode = mode
    if mode == "Frozen" then r.frozen = true; r.state = "Frozen"
    elseif mode == "Invincible" then r.invincible = true
    elseif mode == "Passive" then r.state = "Passive"
    elseif mode == "Hostile" then r.state = "Combat"
    elseif mode == "Guard" then r.state = "Guarding"
    elseif mode == "Flee" then r.state = "Fleeing"
    elseif mode == "Follow" then r.state = "Following"
    elseif mode == "Wander" then r.state = "Wandering"
    else r.state = "Idle" end

    if mode ~= "Frozen" then r.frozen = false end
    if mode ~= "Invincible" then r.invincible = false end

    TriggerClientEvent("testrobot:applyMode", -1, r.netId, mode, r.invincible, r.frozen)
    Notify(src, ("AI %d mode set to %s"):format(r.id, mode), "success")
    SendWebhook("Mode Changed", ("AI %d — %s mode → %s"):format(r.id, r.name, mode), 15844367)
    SyncRobot(src, r.id)
    SyncToOwner(src)
end)

-- ============================================================
-- RULES
-- ============================================================
RegisterNetEvent("testrobot:setRule", function(ruleKey, value)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end

    if r.rules[ruleKey] == nil then
        Notify(src, "Invalid rule.", "error")
        return
    end
    r.rules[ruleKey] = value and true or false
    Notify(src, ("Rule %s set to %s"):format(ruleKey, tostring(r.rules[ruleKey])), "success")
    SyncRobot(src, r.id)
end)

RegisterNetEvent("testrobot:getRules", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:showRules", src, r.id, r.name, r.rules)
end)

-- ============================================================
-- WEAPONS
-- ============================================================
local function IsValidWeapon(w)
    for _, v in ipairs(Config.Weapons) do
        if v == w then return true end
    end
    return false
end

RegisterNetEvent("testrobot:setWeapon", function(weapon, ammo)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end

    if weapon == nil or weapon == "" or weapon == "NONE" then
        r.weapon = nil
        r.ammo = 0
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
        Notify(src, ("AI %d disarmed."):format(r.id), "success")
        SendWebhook("AI Disarmed", ("AI %d — %s"):format(r.id, r.name), 15158332)
    else
        weapon = weapon:upper()
        if not IsValidWeapon(weapon) then
            Notify(src, "Invalid weapon.", "error")
            return
        end
        ammo = tonumber(ammo) or Config.DefaultAmmo
        if ammo < 0 then ammo = 0 end
        if ammo > 9999 then ammo = 9999 end
        r.weapon = weapon
        r.ammo = ammo
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, weapon, ammo)
        Notify(src, ("AI %d armed with %s (x%d)"):format(r.id, weapon, ammo), "success")
        SendWebhook("Weapon Changed", ("AI %d — %s → %s x%d"):format(r.id, r.name, weapon, ammo), 3447003)
    end
    SyncRobot(src, r.id)
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:armAll", function(weapon, ammo)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    weapon = (weapon or Config.DefaultWeapon):upper()
    if not IsValidWeapon(weapon) then weapon = Config.DefaultWeapon end
    ammo = tonumber(ammo) or Config.DefaultAmmo
    for id, r in pairs(Robots) do
        if r.state ~= "Dead" then
            r.weapon = weapon
            r.ammo = ammo
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, weapon, ammo)
        end
    end
    Notify(src, "All AI armed.", "success")
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:disarmAll", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    for id, r in pairs(Robots) do
        r.weapon = nil
        r.ammo = 0
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
    end
    Notify(src, "All AI disarmed.", "success")
    SyncToOwner(src)
end)

-- ============================================================
-- HEALTH / ARMOR
-- ============================================================
RegisterNetEvent("testrobot:setHealth", function(amount)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    amount = tonumber(amount)
    if not amount or amount < 0 then Notify(src, "Invalid amount.", "error"); return end
    if amount > r.maxHealth then amount = r.maxHealth end
    r.health = amount
    if amount > 0 and r.state == "Dead" then
        r.state = "Idle"
    end
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, amount, r.armor, r.invincible)
    Notify(src, ("AI %d health set to %d"):format(r.id, amount), "success")
    SendWebhook("Health Changed", ("AI %d — %s health → %d"):format(r.id, r.name, amount), 3066993)
    SyncRobot(src, r.id)
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:setArmor", function(amount)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    amount = tonumber(amount)
    if not amount or amount < 0 then Notify(src, "Invalid amount.", "error"); return end
    if amount > 100 then amount = 100 end
    r.armor = amount
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, amount, r.invincible)
    Notify(src, ("AI %d armor set to %d"):format(r.id, amount), "success")
    SendWebhook("Armor Changed", ("AI %d — %s armor → %d"):format(r.id, r.name, amount), 3066993)
    SyncRobot(src, r.id)
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:heal", function(all)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    if all then
        for id, r in pairs(Robots) do
            r.health = r.maxHealth
            r.armor = Config.RobotArmor
            if r.state == "Dead" or r.state == "Injured" then r.state = "Idle" end
            TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, r.invincible)
            TriggerClientEvent("testrobot:revivePed", -1, r.netId)
        end
        Notify(src, "All AI healed.", "success")
    else
        local r = GetSelected(src)
        if not r then Notify(src, "No AI selected.", "error"); return end
        r.health = r.maxHealth
        r.armor = Config.RobotArmor
        if r.state == "Dead" or r.state == "Injured" then r.state = "Idle" end
        TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, r.invincible)
        TriggerClientEvent("testrobot:revivePed", -1, r.netId)
        Notify(src, ("AI %d healed/revived."):format(r.id), "success")
        SendWebhook("AI Revived", ("AI %d — %s"):format(r.id, r.name), 3066993)
        SyncRobot(src, r.id)
    end
    SyncToOwner(src)
end)

RegisterNetEvent("testrobot:respawn", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    -- Client will delete old entity and spawn new one, then re-register
    TriggerClientEvent("testrobot:respawnPed", src, r.id, r.type, r.netId)
end)

RegisterNetEvent("testrobot:respawnDone", function(id, newNetId)
    local src = source
    if not IsOwner(src) then return end
    local r = Robots[id]
    if not r then return end
    r.netId = newNetId
    r.health = r.maxHealth
    r.armor = Config.RobotArmor
    r.state = "Idle"
    if r.weapon then
        TriggerClientEvent("testrobot:applyWeapon", -1, newNetId, r.weapon, r.ammo)
    end
    Notify(src, ("AI %d respawned."):format(id), "success")
    SyncRobot(src, id)
    SyncToOwner(src)
end)

-- ============================================================
-- STATS
-- ============================================================
RegisterNetEvent("testrobot:getStats", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:showStats", src, r.id, r.name, r.stats, r.health, r.maxHealth, r.armor, r.state)
end)

RegisterNetEvent("testrobot:resetStats", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.stats = {
        hits = 0, totalDamage = 0, lastDamage = 0,
        lastWeapon = nil, lastBone = nil, lastAttacker = nil, deathCount = r.stats.deathCount or 0
    }
    Notify(src, ("Stats reset for AI %d"):format(r.id), "success")
    SyncRobot(src, r.id)
end)

RegisterNetEvent("testrobot:resetRobot", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.health = r.maxHealth
    r.armor = Config.RobotArmor
    r.mode = "Passive"
    r.state = "Idle"
    r.frozen = false
    r.invincible = false
    r.weapon = nil
    r.ammo = 0
    r.rules = CopyRules()
    r.conversation = {}
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, false)
    TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
    TriggerClientEvent("testrobot:applyAction", -1, r.netId, "STOP", r.id)
    Notify(src, ("AI %d fully reset."):format(r.id), "success")
    SyncRobot(src, r.id)
    SyncToOwner(src)
end)

-- ============================================================
-- DAMAGE / DEATH REPORT FROM CLIENT
-- ============================================================
RegisterNetEvent("testrobot:reportDamage", function(netId, damage, weaponHash, bone, attacker)
    local src = source
    -- any client can report; we map by netId
    for id, r in pairs(Robots) do
        if r.netId == netId and r.state ~= "Dead" then
            r.stats.hits = r.stats.hits + 1
            r.stats.totalDamage = r.stats.totalDamage + (damage or 0)
            r.stats.lastDamage = damage or 0
            r.stats.lastWeapon = weaponHash
            r.stats.lastBone = bone
            r.stats.lastAttacker = attacker
            r.health = math.max(0, r.health - (damage or 0))
            if r.health <= 0 then
                r.state = "Dead"
                r.stats.deathCount = r.stats.deathCount + 1
                SendWebhook("AI Killed", ("AI %d — %s died"):format(r.id, r.name), 15158332)
            elseif r.health < r.maxHealth * 0.3 then
                r.state = "Injured"
            end
            -- notify owner if online
            for pSrc, _ in pairs(Selected) do
                if IsOwner(pSrc) then
                    SyncToOwner(pSrc)
                    if Selected[pSrc] == id then SyncRobot(pSrc, id) end
                end
            end
            break
        end
    end
end)

RegisterNetEvent("testrobot:reportDeath", function(netId)
    for id, r in pairs(Robots) do
        if r.netId == netId then
            r.state = "Dead"
            r.health = 0
            r.stats.deathCount = (r.stats.deathCount or 0) + 1
            SendWebhook("AI Killed", ("AI %d — %s"):format(r.id, r.name), 15158332)
            break
        end
    end
end)

-- ============================================================
-- INVENTORY / LOOT
-- ============================================================
RegisterNetEvent("testrobot:getInventory", function(id)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    id = tonumber(id) or Selected[src]
    local r = Robots[id]
    if not r then Notify(src, "AI missing.", "error"); return end
    TriggerClientEvent("testrobot:showInventory", src, r.id, r.name, r.inventory, r.state == "Dead")
end)

RegisterNetEvent("testrobot:lootItem", function(robotId, itemIndex)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    robotId = tonumber(robotId)
    itemIndex = tonumber(itemIndex)
    local r = Robots[robotId]
    if not r then Notify(src, "AI missing.", "error"); return end
    if r.state ~= "Dead" then
        Notify(src, "Can only loot dead AI.", "error")
        return
    end
    if not itemIndex or not r.inventory[itemIndex] then
        Notify(src, "Invalid item.", "error")
        return
    end
    local item = r.inventory[itemIndex]
    if item.count <= 0 then
        Notify(src, "Item already taken.", "error")
        return
    end

    -- Try real inventory systems
    local given = false
    if GetResourceState("ox_inventory") == "started" then
        local ok = exports.ox_inventory:AddItem(src, item.name, item.count)
        if ok then given = true end
    elseif Framework == "qbcore" and QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            Player.Functions.AddItem(item.name, item.count)
            given = true
        end
    elseif Framework == "qbox" then
        -- qbx usually uses ox_inventory
        if GetResourceState("ox_inventory") == "started" then
            local ok = exports.ox_inventory:AddItem(src, item.name, item.count)
            if ok then given = true end
        end
    elseif Framework == "esx" and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            xPlayer.addInventoryItem(item.name, item.count)
            given = true
        end
    end

    if not given then
        -- standalone: just notify (no real inventory)
        Notify(src, ("Received %s x%d (standalone – no inventory system)"):format(item.label, item.count), "success")
    else
        Notify(src, ("Looted %s x%d"):format(item.label, item.count), "success")
    end

    -- Remove from AI inventory (prevent double loot)
    table.remove(r.inventory, itemIndex)
    SendWebhook("AI Looted", ("AI %d — %s looted %s x%d"):format(r.id, r.name, item.label, item.count), 15844367)
    TriggerClientEvent("testrobot:showInventory", src, r.id, r.name, r.inventory, true)
end)

RegisterNetEvent("testrobot:giveItemToRobot", function(robotId, itemName, count)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    robotId = tonumber(robotId) or Selected[src]
    local r = Robots[robotId]
    if not r then Notify(src, "AI missing.", "error"); return end
    if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end

    itemName = tostring(itemName or "")
    count = tonumber(count) or 1
    if count < 1 then Notify(src, "Invalid amount.", "error"); return end

    -- Attempt to remove from player inventory
    local removed = false
    if GetResourceState("ox_inventory") == "started" then
        local has = exports.ox_inventory:GetItemCount(src, itemName)
        if has and has >= count then
            removed = exports.ox_inventory:RemoveItem(src, itemName, count)
        end
    elseif Framework == "qbcore" and QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName(itemName)
            if item and item.amount >= count then
                Player.Functions.RemoveItem(itemName, count)
                removed = true
            end
        end
    elseif Framework == "esx" and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem(itemName)
            if item and item.count >= count then
                xPlayer.removeInventoryItem(itemName, count)
                removed = true
            end
        end
    else
        -- standalone fallback: allow without removal
        removed = true
    end

    if not removed then
        Notify(src, "Not enough inventory.", "error")
        return
    end

    -- Add to AI inventory
    local found = false
    for _, it in ipairs(r.inventory) do
        if it.name == itemName then
            it.count = it.count + count
            found = true
            break
        end
    end
    if not found then
        r.inventory[#r.inventory + 1] = {
            name = itemName,
            label = itemName,
            count = count,
            type = "item"
        }
    end

    -- If weapon, also equip
    local wUpper = itemName:upper()
    if IsValidWeapon(wUpper) or wUpper:find("WEAPON_") then
        r.weapon = wUpper:find("WEAPON_") and wUpper or ("WEAPON_" .. wUpper)
        r.ammo = r.ammo > 0 and r.ammo or Config.DefaultAmmo
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, r.weapon, r.ammo)
    end

    Notify(src, ("Gave %s x%d to AI %d"):format(itemName, count, r.id), "success")
    SyncRobot(src, r.id)
end)

-- ============================================================
-- ANIMATION
-- ============================================================
RegisterNetEvent("testrobot:anim", function(animName)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end
    animName = tostring(animName or "stop"):lower()
    TriggerClientEvent("testrobot:playAnim", -1, r.netId, animName)
    if animName ~= "stop" then
        r.state = "Idle"
    end
    Notify(src, ("AI %d animation: %s"):format(r.id, animName), "success")
end)

-- ============================================================
-- VEHICLE
-- ============================================================
RegisterNetEvent("testrobot:vehicleAction", function(action)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end

    action = tostring(action or ""):upper()
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, action, Config.VehicleModel, Config.TestWallCoords, Config.TestWallHeading)
end)

RegisterNetEvent("testrobot:vehicleRegistered", function(robotId, vehNetId)
    local src = source
    if not IsOwner(src) then return end
    local r = Robots[robotId]
    if r then
        r.vehicleNetId = vehNetId
        r.state = "Driving"
        SyncRobot(src, robotId)
        SyncToOwner(src)
        SendWebhook("Vehicle Created", ("AI %d — %s received vehicle"):format(r.id, r.name), 3447003)
    end
end)

RegisterNetEvent("testrobot:vehicleCleared", function(robotId)
    local src = source
    if not IsOwner(src) then return end
    local r = Robots[robotId]
    if r then
        r.vehicleNetId = nil
        if r.state == "Driving" or r.state == "Passenger" then r.state = "Idle" end
        SyncRobot(src, robotId)
        SyncToOwner(src)
    end
end)

-- ============================================================
-- TALK / CONVERSATION
-- ============================================================
local function PersonalityReply(personality, text, robotName)
    local lower = text:lower()
    local replies = {
        Friendly = {
            follow = "Sure, Captain Jack. I'll follow you.",
            stop   = "Okay, stopping now.",
            default = "Hello Captain Jack! How can I help?"
        },
        Professional = {
            follow = "Understood. Moving with you.",
            stop   = "Acknowledged. Holding position.",
            default = "Awaiting instructions, Captain Jack."
        },
        Military = {
            follow = "Copy that. Forming up on you.",
            stop   = "Roger. Holding.",
            default = "Copy that. Awaiting your next order."
        },
        Civilian = {
            follow = "Alright, I'm coming.",
            stop   = "Okay, I'll stay here.",
            default = "Yes?"
        },
        Aggressive = {
            follow = "Fine. Leading or following?",
            stop   = "What exactly are you trying to do?",
            default = "What do you want?"
        },
        Coward = {
            follow = "Uh... are you sure this is safe?",
            stop   = "Okay... I'll stay put.",
            default = "Y-yes, Captain?"
        },
        Guard = {
            follow = "Moving to escort position.",
            stop   = "Guarding this position.",
            default = "Report."
        },
        Funny = {
            follow = "Again? You really like testing me, Captain Jack.",
            stop   = "Stopping. Happy now?",
            default = "Hey Captain! What's the plan this time?"
        },
        Developer = {
            follow = "Executing FOLLOW routine.",
            stop   = "Task interrupted. Idle state.",
            default = "Ready for input."
        },
        Neutral = {
            follow = "Following.",
            stop   = "Stopped.",
            default = "Yes?"
        }
    }
    local set = replies[personality] or replies.Neutral
    if lower:find("follow") then return set.follow
    elseif lower:find("stop") or lower:find("stay") then return set.stop
    else return set.default end
end

RegisterNetEvent("testrobot:talk", function(message)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if not r.rules.speak_when_spoken_to then
        Notify(src, "This AI is set not to speak when spoken to.", "info")
        return
    end

    message = tostring(message or ""):sub(1, 200)
    if message == "" then return end

    -- Store history
    r.conversation[#r.conversation + 1] = { from = "Captain Jack", text = message }
    if #r.conversation > Config.ConversationHistoryLimit then
        table.remove(r.conversation, 1)
    end

    -- Safe natural language mapping
    local lower = message:lower()
    local action = nil
    for phrase, act in pairs(Config.NaturalCommands) do
        if lower:find(phrase, 1, true) then
            action = act
            break
        end
    end

    local reply
    if Config.AI.Enabled and Config.AI.ApiKey ~= "" and Config.AI.Endpoint ~= "" then
        -- Optional external AI – response is still mapped to safe actions only
        -- For safety we do a simple local reply; external call can be added by owner
        reply = PersonalityReply(r.personality, message, r.name)
    else
        reply = PersonalityReply(r.personality, message, r.name)
    end

    r.conversation[#r.conversation + 1] = { from = r.name, text = reply }
    if #r.conversation > Config.ConversationHistoryLimit then
        table.remove(r.conversation, 1)
    end

    TriggerClientEvent("testrobot:talkReply", src, r.id, r.name, r.conversation, reply)

    -- Execute safe action if mapped
    if action and r.rules.follow_direct_commands then
        if action == "FOLLOW" then
            r.state = "Following"; r.mode = "Follow"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "FOLLOW", r.id)
        elseif action == "STOP" then
            r.state = "Idle"; r.mode = "Passive"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "STOP", r.id)
        elseif action == "ATTACK" then
            r.state = "Combat"; r.mode = "Hostile"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "ATTACK", r.id)
        elseif action == "PASSIVE" then
            r.state = "Passive"; r.mode = "Passive"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "PASSIVE", r.id)
        elseif action == "GUARD" then
            r.state = "Guarding"; r.mode = "Guard"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "GUARD", r.id)
        elseif action == "FLEE" then
            r.state = "Fleeing"; r.mode = "Flee"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "FLEE", r.id)
        elseif action == "WANDER" then
            r.state = "Wandering"; r.mode = "Wander"
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "WANDER", r.id)
        elseif action == "ENTER_VEHICLE" then
            TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "ENTER", Config.VehicleModel)
        elseif action == "EXIT_VEHICLE" then
            TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "EXIT")
        elseif action == "DRIVE" then
            TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "DRIVE")
        elseif action == "BRAKE" then
            TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "BRAKE")
        elseif action == "REVERSE" then
            TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "REVERSE")
        elseif action == "WEAPON_SHOTGUN" then
            r.weapon = "WEAPON_PUMPSHOTGUN"; r.ammo = Config.DefaultAmmo
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, r.weapon, r.ammo)
        elseif action == "DISARM" then
            r.weapon = nil; r.ammo = 0
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
        elseif action == "ANIM_SIT" then
            TriggerClientEvent("testrobot:playAnim", -1, r.netId, "sit")
        elseif action == "ANIM_STOP" then
            TriggerClientEvent("testrobot:playAnim", -1, r.netId, "stop")
        end
    end
end)

RegisterNetEvent("testrobot:clearConversation", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.conversation = {}
    Notify(src, ("Conversation cleared for AI %d"):format(r.id), "success")
    TriggerClientEvent("testrobot:talkReply", src, r.id, r.name, {}, "")
end)

-- ============================================================
-- DISTURBANCE
-- ============================================================
RegisterNetEvent("testrobot:disturbance", function(netId, reason, count)
    local src = source
    if not IsOwner(src) then return end
    for id, r in pairs(Robots) do
        if r.netId == netId and r.state ~= "Dead" then
            local reactions = Config.DisturbanceReactions[r.personality] or Config.DisturbanceReactions.Neutral
            local msg = reactions[math.random(#reactions)]

            -- Extra lines when repeatedly trolled
            count = tonumber(count) or 1
            if count >= 5 then
                local extra = {
                    Friendly = "Captain Jack, please stop testing me like this...",
                    Professional = "This is highly irregular, Captain.",
                    Military = "Sir, request clear orders instead of harassment.",
                    Civilian = "What the hell is going on?!",
                    Aggressive = "You really want to keep pushing me?",
                    Coward = "Please... I don't like this...",
                    Guard = "Status: agitated. Awaiting real command.",
                    Funny = "Again? You really like testing me, Captain Jack.",
                    Developer = "Stress-test threshold exceeded. Logging incident.",
                    Neutral = "Can you make up your mind?"
                }
                msg = extra[r.personality] or extra.Neutral
            end

            r.state = "Annoyed"
            -- Never auto-attack the owner – rules always win
            -- Speech bubble + notify
            TriggerClientEvent("testrobot:aiSpeak", -1, netId, msg)
            if Selected[src] == id then
                SyncRobot(src, id)
            end
            break
        end
    end
end)

-- ============================================================
-- MENU OPEN / SYNC
-- ============================================================
RegisterNetEvent("testrobot:openMenu", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    SyncToOwner(src)
    local sel = Selected[src]
    if sel and Robots[sel] then SyncRobot(src, sel) end
    TriggerClientEvent("testrobot:openNUI", src)
end)

RegisterNetEvent("testrobot:requestSync", function()
    local src = source
    if not IsOwner(src) then return end
    SyncToOwner(src)
end)

-- ============================================================
-- RESOURCE TOGGLE
-- ============================================================
local SystemEnabled = true

RegisterNetEvent("testrobot:setEnabled", function(state)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    SystemEnabled = state and true or false
    Notify(src, SystemEnabled and "TestRobot enabled." or "TestRobot disabled.", "info")
end)

-- ============================================================
-- WEBHOOK TEST
-- ============================================================
RegisterNetEvent("testrobot:testWebhook", function()
    local src = source
    if not IsOwner(src) then Deny(src); return end
    if not Config.Webhook.Enabled or Config.Webhook.URL == "" then
        Notify(src, "Webhook is disabled or URL is empty.", "error")
        return
    end
    SendWebhook("Webhook Test", "Test message from TestRobot by Captain Jack.", 3447003)
    Notify(src, "Webhook test sent.", "success")
end)

-- ============================================================
-- COMMANDS (all server-side registered)
-- ============================================================
local function RegCmd(name, handler)
    RegisterCommand(name, function(src, args)
        if src == 0 then return end -- console not supported for owner checks
        if not IsOwner(src) then Deny(src); return end
        if not SystemEnabled and name ~= "testrobot" then
            Notify(src, "TestRobot is currently disabled. Use /testrobot on", "error")
            return
        end
        handler(src, args)
    end, false)
end

RegCmd("testrobot", function(src, args)
    local sub = (args[1] or ""):lower()
    if sub == "on" then
        SystemEnabled = true
        Notify(src, "TestRobot enabled.", "success")
    elseif sub == "off" then
        SystemEnabled = false
        Notify(src, "TestRobot disabled.", "info")
    else
        Notify(src, "Usage: /testrobot on | off", "info")
    end
end)

local function SpawnCmd(rtype, armed)
    return function(src, args)
        local amount = tonumber(args[1]) or 1
        if amount < 1 then amount = 1 end
        if CountRobots() >= Config.MaxRobots then
            Notify(src, "You cannot spawn anymore. Delete a robot and spawn again, or try again next time.", "error")
            return
        end
        TriggerClientEvent("testrobot:doSpawn", src, rtype, amount, armed)
    end
end

RegCmd("spawnrobot", SpawnCmd("robot", false))
RegCmd("spawnmale", SpawnCmd("male", false))
RegCmd("spawnfemale", SpawnCmd("female", false))
RegCmd("spawnrobotarmed", function(src, args)
    local amount = tonumber(args[1]) or 1
    if CountRobots() >= Config.MaxRobots then
        Notify(src, "You cannot spawn anymore. Delete a robot and spawn again, or try again next time.", "error")
        return
    end
    TriggerClientEvent("testrobot:doSpawn", src, "robot", amount, true)
end)

-- Pure standing test dummy for testing YOUR menus / targets / scripts
RegCmd("testdummy", function(src, args)
    local amount = tonumber(args[1]) or 1
    if amount < 1 then amount = 1 end
    if CountRobots() >= Config.MaxRobots then
        Notify(src, "You cannot spawn anymore. Delete a robot and spawn again, or try again next time.", "error")
        return
    end
    TriggerClientEvent("testrobot:doSpawn", src, "male", amount, false)
    -- After spawn registers, force passive stand so they stay put for menu testing
    SetTimeout(800, function()
        for id, r in pairs(Robots) do
            if r.state ~= "Dead" then
                r.mode = "Passive"
                r.state = "Idle"
                TriggerClientEvent("testrobot:applyAction", -1, r.netId, "STAND", r.id)
            end
        end
        if IsOwner(src) then
            Notify(src, "Test dummy ready – walk up and test your menus / target / scripts on it.", "success")
            SyncToOwner(src)
        end
    end)
end)

RegisterCommand("menu", function(src)
    if not IsOwner(src) then Deny(src); return end
    SyncToOwner(src)
    if Selected[src] and Robots[Selected[src]] then SyncRobot(src, Selected[src]) end
    TriggerClientEvent("testrobot:openNUI", src)
end, false)

RegisterCommand("robotmenu", function(src)
    if not IsOwner(src) then Deny(src); return end
    SyncToOwner(src)
    if Selected[src] and Robots[Selected[src]] then SyncRobot(src, Selected[src]) end
    TriggerClientEvent("testrobot:openNUI", src)
end, false)

RegCmd("robotselect", function(src, args)
    local id = tonumber(args[1])
    if not id then Notify(src, "Usage: /robotselect [id]", "error"); return end
    if not Robots[id] then Notify(src, "Invalid AI ID.", "error"); return end
    Selected[src] = id
    SyncRobot(src, id)
    Notify(src, ("Selected AI %d — %s"):format(id, Robots[id].name), "success")
    SyncToOwner(src)
end)

RegCmd("robotdelete", function(src, args)
    local id = args[1] and tonumber(args[1]) or nil
    if id then
        if not Robots[id] then Notify(src, "AI missing or invalid ID.", "error"); return end
        local name = Robots[id].name
        DeleteRobot(id)
        Notify(src, ("Deleted AI %d — %s"):format(id, name), "success")
        SendWebhook("AI Deleted", ("AI %d — %s"):format(id, name), 15158332)
    else
        local r = GetSelected(src)
        if not r then Notify(src, "No AI selected.", "error"); return end
        local name = r.name
        local rid = r.id
        DeleteRobot(rid)
        Notify(src, ("Deleted AI %d — %s"):format(rid, name), "success")
        SendWebhook("AI Deleted", ("AI %d — %s"):format(rid, name), 15158332)
    end
    SyncToOwner(src)
end)

RegisterCommand("delete", function(src, args)
    if not IsOwner(src) then Deny(src); return end
    if (args[1] or ""):lower() == "robot" then
        local id = tonumber(args[2])
        if not id or not Robots[id] then Notify(src, "Invalid AI ID.", "error"); return end
        local name = Robots[id].name
        DeleteRobot(id)
        Notify(src, ("Deleted AI %d — %s"):format(id, name), "success")
        SyncToOwner(src)
    end
end, false)

local function DeleteAllCmd(src)
    TriggerClientEvent("testrobot:confirmDeleteAll", src)
end
RegCmd("deleteall", DeleteAllCmd)
RegCmd("deleteallrobots", DeleteAllCmd)
RegCmd("robotsdeleteall", DeleteAllCmd)

RegCmd("robotfollow", function(src) TriggerClientEvent("testrobot:serverAction", src, "FOLLOW", false) end)
-- Better: direct action
local function Act(action, all)
    return function(src)
        local targets = {}
        if all then
            for _, r in pairs(Robots) do if r.state ~= "Dead" then targets[#targets+1] = r end end
        else
            local r = GetSelected(src)
            if not r then Notify(src, "No AI selected.", "error"); return end
            if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end
            targets[1] = r
        end
        for _, r in ipairs(targets) do
            if action == "FOLLOW" then r.state = "Following"; r.mode = "Follow"
            elseif action == "STOP" then r.state = "Idle"; r.mode = "Passive"
            elseif action == "ATTACK" then r.state = "Combat"; r.mode = "Hostile"
            elseif action == "PASSIVE" then r.state = "Passive"; r.mode = "Passive"
            elseif action == "GUARD" then r.state = "Guarding"; r.mode = "Guard"
            elseif action == "FLEE" then r.state = "Fleeing"; r.mode = "Flee"
            elseif action == "FREEZE" then r.frozen = true; r.state = "Frozen"; r.mode = "Frozen"
            elseif action == "UNFREEZE" then r.frozen = false; r.state = "Idle"; if r.mode == "Frozen" then r.mode = "Passive" end
            elseif action == "WANDER" then r.state = "Wandering"; r.mode = "Wander"
            elseif action == "STAND" then r.state = "Idle"; r.mode = "Passive"
            elseif action == "CHASE" then r.state = "Following"; r.mode = "Follow"
            elseif action == "COMBAT" then r.state = "Combat"; r.mode = "Hostile"
            elseif action == "NOCOMBAT" then r.state = "Passive"; r.mode = "Passive"
            end
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, action, r.id)
        end
        SyncToOwner(src)
        local sel = GetSelected(src)
        if sel then SyncRobot(src, sel.id) end
        Notify(src, action .. (all and " (all)" or ""), "success")
    end
end

RegCmd("robotfollow", Act("FOLLOW", false))
RegCmd("robotstop", Act("STOP", false))
RegCmd("robotattack", Act("ATTACK", false))
RegCmd("robotpassive", Act("PASSIVE", false))
RegCmd("robotguard", Act("GUARD", false))
RegCmd("robotflee", Act("FLEE", false))
RegCmd("robotfreeze", Act("FREEZE", false))
RegCmd("robotunfreeze", Act("UNFREEZE", false))
RegCmd("robotwander", Act("WANDER", false))
RegCmd("robotstand", Act("STAND", false))
RegCmd("robotchase", Act("CHASE", false))
RegCmd("robotcombat", Act("COMBAT", false))
RegCmd("robotnocombat", Act("NOCOMBAT", false))

RegCmd("robotfollowall", Act("FOLLOW", true))
RegCmd("robotstopall", Act("STOP", true))
RegCmd("robotpassiveall", Act("PASSIVE", true))
RegCmd("robotfreezeall", Act("FREEZE", true))
RegCmd("robotunfreezeall", Act("UNFREEZE", true))

RegCmd("robotmode", function(src)
    TriggerClientEvent("testrobot:openModeMenu", src, Config.Modes)
end)

RegCmd("robotrules", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:showRules", src, r.id, r.name, r.rules)
end)

RegCmd("robotrule", function(src, args)
    local key = args[1]
    if not key then Notify(src, "Usage: /robotrule [rule_key]", "error"); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if r.rules[key] == nil then Notify(src, "Invalid rule. Check /robotrules", "error"); return end
    r.rules[key] = not r.rules[key]
    Notify(src, ("Rule %s → %s"):format(key, tostring(r.rules[key])), "success")
    SyncRobot(src, r.id)
end)

RegCmd("setrobothealth", function(src, args)
    local amount = tonumber(args[1])
    if not amount then Notify(src, "Usage: /setrobothealth [amount]", "error"); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if amount < 0 then amount = 0 end
    if amount > r.maxHealth then amount = r.maxHealth end
    r.health = amount
    if amount > 0 and r.state == "Dead" then r.state = "Idle" end
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, amount, r.armor, r.invincible)
    Notify(src, ("Health set to %d"):format(amount), "success")
    SyncRobot(src, r.id); SyncToOwner(src)
end)

RegCmd("setrobotarmor", function(src, args)
    local amount = tonumber(args[1])
    if not amount then Notify(src, "Usage: /setrobotarmor [amount]", "error"); return end
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    if amount < 0 then amount = 0 end
    if amount > 100 then amount = 100 end
    r.armor = amount
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, amount, r.invincible)
    Notify(src, ("Armor set to %d"):format(amount), "success")
    SyncRobot(src, r.id); SyncToOwner(src)
end)

RegCmd("robothealth", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    Notify(src, ("AI %d Health: %d / %d"):format(r.id, r.health, r.maxHealth), "info")
end)

RegCmd("robotarmor", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    Notify(src, ("AI %d Armor: %d"):format(r.id, r.armor), "info")
end)

RegCmd("giverobothealth", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.health = r.maxHealth
    r.armor = Config.RobotArmor
    if r.state == "Dead" or r.state == "Injured" then r.state = "Idle" end
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, r.invincible)
    TriggerClientEvent("testrobot:revivePed", -1, r.netId)
    Notify(src, ("AI %d healed/revived."):format(r.id), "success")
    SyncRobot(src, r.id); SyncToOwner(src)
end)

RegCmd("robothealall", function(src)
    for _, r in pairs(Robots) do
        r.health = r.maxHealth
        r.armor = Config.RobotArmor
        if r.state == "Dead" or r.state == "Injured" then r.state = "Idle" end
        TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, r.invincible)
        TriggerClientEvent("testrobot:revivePed", -1, r.netId)
    end
    Notify(src, "All AI healed.", "success")
    SyncToOwner(src)
end)

RegCmd("robotrespawn", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:respawnPed", src, r.id, r.type, r.netId)
end)

RegCmd("resetrobot", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.health = r.maxHealth; r.armor = Config.RobotArmor
    r.mode = "Passive"; r.state = "Idle"; r.frozen = false; r.invincible = false
    r.weapon = nil; r.ammo = 0; r.rules = CopyRules(); r.conversation = {}
    TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, false)
    TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
    TriggerClientEvent("testrobot:applyAction", -1, r.netId, "STOP", r.id)
    Notify(src, ("AI %d reset."):format(r.id), "success")
    SyncRobot(src, r.id); SyncToOwner(src)
end)

RegCmd("robotstats", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:showStats", src, r.id, r.name, r.stats, r.health, r.maxHealth, r.armor, r.state)
end)

RegCmd("resetrobotstats", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.stats = { hits=0, totalDamage=0, lastDamage=0, lastWeapon=nil, lastBone=nil, lastAttacker=nil, deathCount=r.stats.deathCount or 0 }
    Notify(src, "Stats reset.", "success")
end)

-- Weapons shortcuts
local function WeaponCmd(weapon)
    return function(src)
        local r = GetSelected(src)
        if not r then Notify(src, "No AI selected.", "error"); return end
        if r.state == "Dead" then Notify(src, "AI is dead.", "error"); return end
        r.weapon = weapon
        r.ammo = Config.DefaultAmmo
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, weapon, r.ammo)
        Notify(src, ("Armed with %s"):format(weapon), "success")
        SyncRobot(src, r.id); SyncToOwner(src)
    end
end

RegCmd("robotpistol", WeaponCmd("WEAPON_PISTOL"))
RegCmd("robotsmg", WeaponCmd("WEAPON_SMG"))
RegCmd("robotrifle", WeaponCmd("WEAPON_ASSAULTRIFLE"))
RegCmd("robotshotgun", WeaponCmd("WEAPON_PUMPSHOTGUN"))
RegCmd("robotsniper", WeaponCmd("WEAPON_SNIPERRIFLE"))
RegCmd("robotknife", WeaponCmd("WEAPON_KNIFE"))

RegCmd("robotweapon", function(src)
    TriggerClientEvent("testrobot:openWeaponMenu", src, Config.Weapons, Config.WeaponLabels)
end)

RegCmd("robotdisarm", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    r.weapon = nil; r.ammo = 0
    TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
    Notify(src, "Disarmed.", "success")
    SyncRobot(src, r.id); SyncToOwner(src)
end)

RegCmd("robotarmall", function(src)
    for _, r in pairs(Robots) do
        if r.state ~= "Dead" then
            r.weapon = Config.DefaultWeapon; r.ammo = Config.DefaultAmmo
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, r.weapon, r.ammo)
        end
    end
    Notify(src, "All AI armed.", "success"); SyncToOwner(src)
end)

RegCmd("robotdisarmall", function(src)
    for _, r in pairs(Robots) do
        r.weapon = nil; r.ammo = 0
        TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
    end
    Notify(src, "All AI disarmed.", "success"); SyncToOwner(src)
end)

RegCmd("robotanim", function(src, args)
    local anim = (args[1] or "stop"):lower()
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:playAnim", -1, r.netId, anim)
    Notify(src, ("Animation: %s"):format(anim), "success")
end)

RegCmd("robotvehicle", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "SPAWN", Config.VehicleModel)
end)

RegCmd("robotdrive", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "DRIVE")
end)

RegCmd("robotdrivewall", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "DRIVE_WALL", Config.VehicleModel, Config.TestWallCoords, Config.TestWallHeading)
end)

RegCmd("robotvehicleoff", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "DELETE")
end)

RegCmd("robotexitvehicle", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "EXIT")
end)

RegCmd("robotdriveforward", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "DRIVE")
end)

RegCmd("robotreverse", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "REVERSE")
end)

RegCmd("robotbrake", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "BRAKE")
end)

RegCmd("robotcrash", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:vehicleCmd", src, r.netId, r.id, "CRASH")
end)

RegCmd("talk", function(src)
    local r = GetSelected(src)
    if not r then Notify(src, "No AI selected.", "error"); return end
    TriggerClientEvent("testrobot:openTalk", src, r.id, r.name, r.conversation)
end)

RegCmd("testrobotwebhook", function(src)
    if not Config.Webhook.Enabled or Config.Webhook.URL == "" then
        Notify(src, "Webhook disabled or URL empty.", "error"); return
    end
    SendWebhook("Webhook Test", "Test from TestRobot by Captain Jack.", 3447003)
    Notify(src, "Webhook test sent.", "success")
end)

-- ============================================================
-- NUI CALLBACKS (via client events)
-- ============================================================
RegisterNetEvent("testrobot:nuiAction", function(data)
    local src = source
    if not IsOwner(src) then Deny(src); return end
    if type(data) ~= "table" then return end
    local action = data.action
    if action == "select" then
        local id = tonumber(data.id)
        if id and Robots[id] then
            Selected[src] = id
            SyncRobot(src, id)
            SyncToOwner(src)
        end
    elseif action == "delete" then
        local id = tonumber(data.id)
        if id and Robots[id] then
            local name = Robots[id].name
            DeleteRobot(id)
            Notify(src, ("Deleted AI %d — %s"):format(id, name), "success")
            SyncToOwner(src)
        end
    elseif action == "deleteAllConfirm" then
        local count = CountRobots()
        DeleteAllRobots()
        Notify(src, ("Deleted all %d AI."):format(count), "success")
        SyncToOwner(src)
    elseif action == "control" then
        local act = tostring(data.control or ""):upper()
        local r = GetSelected(src)
        if r and ValidActions[act] then
            -- reuse Act logic
            if act == "FOLLOW" then r.state = "Following"; r.mode = "Follow"
            elseif act == "STOP" then r.state = "Idle"; r.mode = "Passive"
            elseif act == "ATTACK" then r.state = "Combat"; r.mode = "Hostile"
            elseif act == "PASSIVE" then r.state = "Passive"; r.mode = "Passive"
            elseif act == "GUARD" then r.state = "Guarding"; r.mode = "Guard"
            elseif act == "FLEE" then r.state = "Fleeing"; r.mode = "Flee"
            elseif act == "FREEZE" then r.frozen = true; r.state = "Frozen"; r.mode = "Frozen"
            elseif act == "UNFREEZE" then r.frozen = false; r.state = "Idle"
            elseif act == "WANDER" then r.state = "Wandering"; r.mode = "Wander"
            end
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, act, r.id)
            SyncRobot(src, r.id); SyncToOwner(src)
        end
    elseif action == "setMode" then
        local mode = data.mode
        local r = GetSelected(src)
        if r and mode then
            r.mode = mode
            TriggerClientEvent("testrobot:applyMode", -1, r.netId, mode, r.invincible, r.frozen)
            SyncRobot(src, r.id); SyncToOwner(src)
        end
    elseif action == "setWeapon" then
        local weapon = data.weapon
        local r = GetSelected(src)
        if r then
            if not weapon or weapon == "NONE" then
                r.weapon = nil; r.ammo = 0
            else
                r.weapon = weapon; r.ammo = Config.DefaultAmmo
            end
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, r.weapon, r.ammo)
            SyncRobot(src, r.id); SyncToOwner(src)
        end
    elseif action == "talk" then
        -- handled by talk event
    elseif action == "clearTalk" then
        local r = GetSelected(src)
        if r then r.conversation = {} end
    elseif action == "loot" then
        -- open inventory for dead
        local id = tonumber(data.id)
        local r = Robots[id]
        if r and r.state == "Dead" then
            TriggerClientEvent("testrobot:showInventory", src, r.id, r.name, r.inventory, true)
        end
    elseif action == "setRule" then
        local r = GetSelected(src)
        if r and data.rule and r.rules[data.rule] ~= nil then
            r.rules[data.rule] = data.value and true or false
            SyncRobot(src, r.id)
        end
    elseif action == "heal" then
        local r = GetSelected(src)
        if r then
            r.health = r.maxHealth; r.armor = Config.RobotArmor
            if r.state == "Dead" then r.state = "Idle" end
            TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, r.invincible)
            TriggerClientEvent("testrobot:revivePed", -1, r.netId)
            SyncRobot(src, r.id); SyncToOwner(src)
        end
    elseif action == "anim" then
        local r = GetSelected(src)
        if r and data.anim then
            TriggerClientEvent("testrobot:playAnim", -1, r.netId, data.anim)
        end
    elseif action == "reset" then
        local r = GetSelected(src)
        if r then
            r.health = r.maxHealth
            r.armor = Config.RobotArmor
            r.mode = "Passive"
            r.state = "Idle"
            r.frozen = false
            r.invincible = false
            r.weapon = nil
            r.ammo = 0
            r.rules = CopyRules()
            r.conversation = {}
            TriggerClientEvent("testrobot:applyHealth", -1, r.netId, r.health, r.armor, false)
            TriggerClientEvent("testrobot:applyWeapon", -1, r.netId, nil, 0)
            TriggerClientEvent("testrobot:applyAction", -1, r.netId, "STOP", r.id)
            SyncRobot(src, r.id)
            SyncToOwner(src)
            Notify(src, ("AI %d reset."):format(r.id), "success")
        end
    end
end)

-- ============================================================
-- CLEANUP ON RESOURCE STOP
-- ============================================================
AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    ResourceActive = false
    for id, r in pairs(Robots) do
        TriggerClientEvent("testrobot:deleteEntity", -1, r.netId, r.vehicleNetId)
    end
    Robots = {}
    FreeIds = {}
    Selected = {}
    print("^1[testrobot]^7 Cleaned up all AI entities.")
end)

-- ============================================================
-- PERIODIC LIGHTWEIGHT TICK (server keeps state consistent)
-- ============================================================
CreateThread(function()
    while true do
        Wait(5000)
        if not ResourceActive then break end
        -- Just ensure dead AIs stay marked; no heavy work
        for id, r in pairs(Robots) do
            if r.health <= 0 and r.state ~= "Dead" then
                r.state = "Dead"
            end
        end
    end
end)

print("^2[testrobot]^7 Server started. Owner license protected. Max AI: " .. Config.MaxRobots)
